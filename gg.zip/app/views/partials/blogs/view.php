<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("blogs/add");
$can_edit = ACL::is_allowed("blogs/edit");
$can_view = ACL::is_allowed("blogs/view");
$can_delete = ACL::is_allowed("blogs/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container-fluid">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title"><div class="col-12 p-md-4">
                        <div class="row">
                            <div class="col-md-12 col-12 mb-3 comp-grid">
                                <div class="rounded shadow text-white">
                                    <div class="col-12 p-0">
                                        <?php html::page_img($data['banner'],200,60,1,'','rounded fill shadow-lg');?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 mb-3 comp-grid">
                                <div class="fill d-flex align-items-end">
                                    <span>
                                        <span class="d-block mb-2">
                                            <i class="icon-music-tone mr-3"></i> 
                                            <span class="mr-2"><h1><?php echo $data['headline'] ?></h1></span>
                                        </span>
                                        <span class="d-block mt-3">
                                            <a class="btn border rounded">
                                                <i class="icon-user mr-3"></i> 
                                                <span class="d-none d-sm-inline"><?php echo $data['posted_by'];?></span>
                                            </a>
                                            <a class="btn border rounded">
                                                <i class="icon-clock mr-3"></i> 
                                                <span class="d-none d-sm-inline"> 
                                                <?php echo $data['date'] ?></span>
                                            </a>
                                            <a class="btn border rounded">
                                                <i class="icon-heart mr-2"></i>
                                                <span class="d-none d-sm-inline">
                                                <?php echo $data['tags'];?></span>
                                            </a>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="disqus_thread"></div>
                    <script>
                        /**
                        *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
                        *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
                        /*
                        var disqus_config = function () {
                        this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
                        this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
                        };
                        */
                        (function() { // DON'T EDIT BELOW THIS LINE
                        var d = document, s = d.createElement('script');
                        s.src = 'https://gamer-lounge-ke.disqus.com/embed.js';
                        s.setAttribute('data-timestamp', +new Date());
                        (d.head || d.body).appendChild(s);
                        })();
                    </script>
                <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript></h4>
            </div>
        </div>
    </div>
</div>
<?php
}
?>
<div  class="">
    <div class="container">
        <div class="row ">
            <div class="col-md-12 comp-grid">
            </div>
        </div>
    </div>
</div>
</section>
