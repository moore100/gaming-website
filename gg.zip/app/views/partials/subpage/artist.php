<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("subpage/add");
$can_edit = ACL::is_allowed("subpage/edit");
$can_view = ACL::is_allowed("subpage/view");
$can_delete = ACL::is_allowed("subpage/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <div >artist
                        <?php 
                        if(!empty($records)){?>
                        <div class="">
                            <div class="scroll-resp"> 
                                <div class="col-lg-2 col-md-3 col-3 mb-3 p-2">
                                    <a class="d-block shadow o-none no-d col-12 p-0 rounded-circle page-modal" href="<?php print_link("music/add")?>"><img src="<?php print_link(set_img_src(USER_PHOTO,200,200));?>"/>
                                        <div class="uk-overlay uk-position-cover theme-skin uk-light">
                                            <i class="uk-position-center" uk-overlay-icon></i>
                                        </div>
                                    </a>
                                    <div class="text-center text-dark small text-truncate mt-2">
                                        Your music
                                    </div>
                                </div>
                                <?php 
                                $counter =  0;
                                shuffle($records);
                                foreach($records as $data){
                                $rec_id = (!empty($data['id']) ? urlencode($data['id']):null);
                                $counter ++;?>
                                <div class="col-lg-2 col-md-3 col-3 mb-3 p-2"
                                    onclick="playMedia('<?php print_link($data['audio'])?>' , '<?php print_link(set_img_src($data['cover'],200,200));?>' , '<?php echo $data['title'] ?>')">
                                    <a class="d-block no-d" >
                                        <img class="shadow rounded-circle" src="<?php print_link(set_img_src($data['cover'],200,200));?>"/>
                                            <div class="text-center small text-truncate mt-2">
                                                <?php echo $data['artist']?>
                                            </div>
                                        </a>
                                    </div>
                                    <?php 
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                            }
                        ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
