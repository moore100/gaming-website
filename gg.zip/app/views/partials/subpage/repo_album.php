<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("subpage/add");
$can_edit = ACL::is_allowed("subpage/edit");
$can_view = ACL::is_allowed("subpage/view");
$can_delete = ACL::is_allowed("subpage/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <div ><div class="" id="">
                        <?php
                        $mrad_rec = ['','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
                        foreach($mrad_rec as $myrec){
                        if(!empty($records)){?>
                        <div class="">
                            <div class="row mb-4"> 
                                <?php
                                foreach($records as $data){
                                $artist = str_truncate($data['album'],1,''); $artist = ucwords($artist);
                                if($myrec == $artist) { ?>
                                <div class="col-lg-3 col-md-4 parent col-sm-4 col-6 mb-3 comp-grid">
                                    <a class="fill no-d p-md-3 p-3 d-block theme-1gt rounded shadow-sm" href="<?php print_link("music/view_album/$data[id]");?>">
                                        <div class="py-md-3 uk-overlay-cover uk-light">
                                            <div class="icon-music-tone-alt album-icon text-white my-2"></div>
                                            <h4 class="d-block bold text-truncate"><?php echo $data['album']?></h4>
                                            <small class="text-truncate"><?php echo $data['artist']?></small>
                                        </div>
                                    </a>
                                </div>
                                <?php 
                                }
                                } ?>
                            </div>
                        </div>
                        <?php
                        }
                        } 
                        ?>
                    </div></div>
                </div>
            </div>
        </div>
    </div>
</section>
