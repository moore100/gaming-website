<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("page/add");
$can_edit = ACL::is_allowed("page/edit");
$can_view = ACL::is_allowed("page/view");
$can_delete = ACL::is_allowed("page/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="pb-5">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-12 p-0 mb-2 ">
                    <div class="col-12 banner"  uk-sticky="media: 574"  id=""><div class="justify-content-between align-items-end">
                        <div class="">
                            <a class="btn p-0" onclick="goback()"><i class="icon-arrow-left"></i></a>
                        </div>
                        <div class="col-12 p-0 display-5 text-theme pt-3 text-truncate">
                            Playlist
                        </div>
                        <div class="col-12 p-0">
                            <a class="btn btn-sm border-left">
                                <i class="icon-shuffle mr-1"></i> Shuffle (24)
                            </a>
                            <a class="btn btn-sm">
                                <i class="icon-drop mr-1"></i> Sort by 
                                <span class="text-muted bold">A</span> - <span class="text-muted bold">Z</span>
                            </a>
                            <a class="dropdown">
                                <a class="btn btn-sm mrad-btn" data-toggle="dropdown">
                                    <i class="icon-arrow-down"></i>
                                </a>
                                <div class="dropdown-menu shadow border-0">
                                    <a class="dropdown-item">
                                        <i class="icon-grid mr-2"></i> Option One
                                    </a>
                                    <a class="dropdown-item">
                                        <i class="icon-grid mr-2"></i> Switch Grid
                                    </a>
                                </div>
                            </a>
                            <span class="d-none d-md-none d-sm-inline">
                                <form class="uk-search uk-search-default">
                                    <span uk-search-icon></span>
                                    <input class="uk-search-input" placeholder="Search" name="search" type="search" autocomplete="off"></input>
                                </form>
                            </span>
                        </div>
                    </div></div>
                </div>
                <div class="col-md-12 comp-grid">
                    <div ><?php 
                        if(!empty($records)){?>
                        <div class="">
                            <div class="row">
                                <?php 
                                $counter =  0;
                                foreach($records as $data){
                                $rec_id = (!empty($data['id']) ? urlencode($data['id']):null);
                                $counter ++;?>
                                <div class="col-12">
                                    <div class="row py-3 <?php if(($counter%2) == 1){?>stripe-hover<?php } ?> mrad-hover">
                                        <div class="col-md-1 col-2 mrad-td-cover">
                                            <img class="rounded shadow-sm" height="35px" width="35px" src="<?php print_link(set_img_src($data['cover'],35,35))?>"/>
                                            </div>
                                            <div class="col mrad-td-title">
                                                <?php echo $data['title']; ?>
                                                <div class="d-block d-sm-none mb-2 ">
                                                    <?php if(!empty($data['artist'])){ echo $data['artist'];} if(!empty($data['album'])) { echo '--'; echo $data['album'];} if(!empty($data['role'])){ echo '--'; echo $data['role']; }?>
                                                </div>
                                                <div class="d-block d-sm-none">
                                                    <a class="icon-control-play pl-0 btn shadow-0" onclick="playMedia('<?php echo $data['audio'])?>' , '<?php print_link(set_img_src($data['cover'],200,200));?>' , '<?php echo $data['title'] ?>')"></a>
                                                    <span class="dropdown">
                                                        <a class="btn" data-toggle="dropdown" type="button"><i class="icon-options"></i></a>
                                                        <div class="dropdown-menu border-0 shadow">
                                                            <div class="small">
                                                                <a class="dropdown-item text-muted" href="">
                                                                    <i class="icon-heart mr-2"></i> Heart
                                                                </a>
                                                                <?php if(!empty($data['album'])){ ?>
                                                                <a class="dropdown-item text-muted" href="<?php print_link("music/view_album/album/$data[album]");?>">
                                                                    <i class="icon-microphone mr-2"></i> view album
                                                                </a>
                                                                <?php } ?>
                                                                <?php if(!empty($data['artist'])){ ?>
                                                                <a class="dropdown-item text-muted" href="<?php print_link("music/view_artist/artist/$data[artist]");?>">
                                                                    <i class="icon-user mr-2"></i> view artist
                                                                </a>
                                                                <?php } ?>
                                                                <a class="dropdown-item text-muted page-modal" href="<?php print_link("music/sm_view/$data[id]");?>">
                                                                    <i class="icon-docs mr-2"></i> properties
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-2 mrad-td-control">
                                                <div class="d-sm-block d-none">
                                                    <a class="icon-control-play btn shadow-0" onclick="playMedia('<?php print_link($data['audio'])?>' , '<?php print_link(set_img_src($data['cover'],200,200));?>' , '<?php echo $data['title'] ?>')"></a>
                                                    <span class="dropdown">
                                                        <a class="btn" data-toggle="dropdown" type="button"><i class="icon-options"></i></a>
                                                        <div class="dropdown-menu border-0 shadow">
                                                            <div class="small">
                                                                <a class="dropdown-item text-muted" href="">
                                                                    <i class="icon-heart mr-2"></i> Heart
                                                                </a>
                                                                <?php if(!empty($data['album'])){ ?>
                                                                <a class="dropdown-item text-muted mrad-td-album" href="<?php print_link("music/view_album/album/$data[album]");?>">
                                                                    <i class="icon-microphone mr-2"></i> view album
                                                                </a>
                                                                <?php } ?>
                                                                <?php if(!empty($data['artist'])){ ?>
                                                                <a class="dropdown-item text-muted mrad-td-artist" href="<?php print_link("music/view_artist/artist/$data[artist]");?>">
                                                                    <i class="icon-user mr-2"></i> view artist
                                                                </a>
                                                                <?php } ?>
                                                                <a class="dropdown-item text-muted page-modal mrad-td-property" href="<?php print_link("music/sm_view/$data[id]");?>">
                                                                    <i class="icon-info mr-2"></i> properties
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-2 d-none d-sm-block text-truncate mrad-td-artist">
                                                <?php if(!empty($data['artist'])) { echo $data['artist']; } else { echo 'Unknown artist' ;}?>
                                            </div>
                                            <div class="col-2 d-none d-md-block text-truncate mrad-td-album">
                                                <?php if(!empty($data['album'])) { echo $data['album']; } else { echo 'Unknown album' ;}?>
                                            </div>
                                            <div class="col-2 d-none d-md-block text-truncate mrad-td-role">
                                                <?php if(!empty($data['role'])) { echo $data['role']; } else { echo 'Unknown role' ;}?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php 
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                            }
                        ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
