<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("music/add");
$can_edit = ACL::is_allowed("music/edit");
$can_view = ACL::is_allowed("music/view");
$can_delete = ACL::is_allowed("music/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="pb-5">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-12 my-5 ">
                    <div ><div class="col-12 p-md-4">
                        <div class="row">
                            <div class="col-md-4 col-10 mb-3 comp-grid">
                                <div class="theme-1gt rounded shadow text-white">
                                    <div class="uk-overlay py-5 uk-overlay-cover text-capitalize">
                                        <div class="mb-3"><i class="icon-music-tone-alt" style="font-size:100px;"></i></div>
                                        <div class="col-12 p-0 display-4 text-white text-truncate">
                                            <?php echo $data['album'];?>
                                        </div>
                                        <h4 class=" text-white bold "><?php echo $data['artist'];?></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 mb-3 comp-grid">
                                <div class="fill d-flex align-items-end">
                                    <span>
                                        <span class="d-block mb-2">
                                            <i class="icon-microphone mr-3"></i>
                                            <span class="mr-2">Album Name: </span>
                                            <?php if(!empty($data['artist'])){ ?> <?php echo $data['album'] ?>
                                            <a class="icon-eye" href="<?php print_link("music/view_artist/artist/$data[artist]");?>"></a>
                                            <?php } else { ?> <?php echo 'Uknown Album' ?> <?php } ?>
                                        </span>
                                        <span class="d-block mb-2">
                                            <i class="icon-user-follow mr-3"></i> 
                                            <span class="mr-2">Artist Name: </span>
                                            <?php echo $data['artist'] ?>
                                        </span>
                                        <span class="d-block mb-2">
                                            <i class="icon-globe mr-3"></i> 
                                            <span class="mr-2">Host: </span>
                                            <?php echo SITE_NAME ?>
                                        </span>
                                        <span class="d-block mb-2">
                                            <i class="icon-user mr-3"></i> 
                                            <?php echo 'Wilson John' ?>
                                            <span class="mr-2">Uploaded  by: </span>
                                        </span>
                                        <span class="d-block mb-2">
                                            <i class="icon-clock mr-3"></i> 
                                            <span class="mr-2">Date: </span>
                                            <?php echo human_date($data['date']) ?>
                                        </span>
                                        <span class="d-block mt-3">
                                            <a class="btn border rounded">
                                                <i class="icon-control-play mr-2"></i> 
                                                <span class="d-none d-sm-inline">Play All</span>
                                            </a>
                                            <a class="btn border rounded">
                                                <i class="icon-pin mr-2"></i> 
                                                <span class="d-none d-sm-inline"> Pin to tepository</span>
                                            </a>
                                            <a class="btn border rounded">
                                                <i class="icon-heart mr-2"></i>
                                                <span class="d-none d-sm-inline">Heart</span>
                                            </a>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div></div>
                </div>
                <div class="col-md-12 p-0 comp-grid">
                    <div ><div class="col-12 mb-3 text-theme display-5">
                        More of <?php echo $data['album'];?>
                    </div>
                    <div class="col-12">
                        <style>
                            .td-album{
                            display:none;
                            }
                        </style>
                        <?php if(!empty($data['album'])){ $this->render_page("music/sm_list/album/$data[album]"); } else { $this->render_page("music/sm_list/album");} ;?>
                    </div></div>
                </div>
            </div>
        </div>
    </div>
</section>
