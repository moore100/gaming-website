<?php
$comp_model = new SharedController;
$page_element_id = "add-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="add"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <div  class="p-3">
        <div class="container">
            <div class="row ">
                <div class="col-sm-12 my-3 comp-grid">
                    <h4 class="text-auto"><div class="display-5 pt-3 text-truncate">
                        Upload Music
                    </div></h4>
                </div>
                <div class="col-sm-12 theme-bw shadow mb-5 mb-sm-0 comp-grid">
                    <div class="py-4 px-md-3"><form id="music-pc_add-form" role="form" novalidate enctype="multipart/form-data" class="form page-form form-horizontal needs-validation" action="<?php print_link("music/pc_add?csrf_token=$csrf_token") ?>" method="post">
                        <div class="">
                            <div class="row">
                                <!--text fields-->
                                <div class="col-sm-7 col-12 order-md-1 order-3">
                                    <div class="row">
                                        <div class="col-12 col-sm-6 mb-3">
                                            <div class="form-holder">
                                                <!--<div class="text-auto">Title</div>-->
                                                <input id="ctrl-title"  value="<?php  echo $this->set_field_value('title',""); ?>" type="text" placeholder="Audio Title"  required="" name="title"  class="form-control " />
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-6 mb-3">
                                                <div class="form-holder">
                                                    <!--<div class="text-auto">Artist Name</div>-->
                                                    <input id="ctrl-artist"  value="<?php  echo $this->set_field_value('artist',""); ?>" type="text" placeholder="Artist Name"  name="artist"  class="form-control " />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12 col-sm-6 mb-3">
                                                    <div class="form-holder">
                                                        <!--<div class="text-auto">Album</div>-->
                                                        <input id="ctrl-album"  value="<?php  echo $this->set_field_value('album',""); ?>" type="text" placeholder="Album"  name="album"  class="form-control " />
                                                        </div>
                                                    </div>
                                                    <div class="col-12 col-sm-6 mb-3">
                                                        <div class="form-holder">
                                                            <!--<div class="text-auto">Year</div>-->
                                                            <input id="ctrl-year"  value="<?php  echo $this->set_field_value('year',""); ?>" type="text" placeholder="Year"  name="year"  class="form-control " />
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-sm-6 mb-3">
                                                            <div class="form-holder">
                                                                <!--<div class="text-auto">role</div>-->
                                                                <select required="" data-endpoint="<?php print_link('api/json/music_role_option_list') ?>" id="ctrl-role" name="role"  placeholder="category"    class="selectize-ajax bg-0" >
                                                                    <option value="">Category ...</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--file fields-->
                                                <div class="col order-2">
                                                    <!--adio path-->
                                                    <div class="mb-1">
                                                        <div class="form-group ">
                                                            <div class="row">
                                                                <div class="col-12">
                                                                    <div class="">
                                                                        <div class="col-12 col-sm-6 mb-3">
                                                                            <div class="form-holder">
                                                                                <!--<div class="text-auto">Year</div>-->
                                                                                <input id="ctrl-audio"  value="<?php  echo $this->set_field_value('audio',""); ?>" type="text" placeholder="audio"  name="year"  class="form-control " />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--adio cover-->
                                                        <div class="mb-1">
                                                            <div class="form-group ">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="">
                                                                            <div class="dropzone required" input="#ctrl-cover" fieldname="cover"    data-multiple="false" dropmsg="Choose audio image"    btntext="Browse" extensions=".jpg,.png,.gif,.jpeg" filesize="5" maximum="1" style="border-width:1px; background:rgba(0,0,0,0.03);">
                                                                                <input name="cover" id="ctrl-cover" required="" class="dropzone-input form-control" value="<?php  echo $this->set_field_value('cover',""); ?>" type="text"  />
                                                                                    <!--<div class="invalid-feedback animated bounceIn text-center">Please a choose file</div>-->
                                                                                    <div class="dz-file-limit animated bounceIn text-center text-danger"></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="form-group form-submit-btn-holder mt-3">
                                                    <div class="form-ajax-status"></div>
                                                    <button class="btn btn-danger" type="submit">
                                                        Submit to uplaod
                                                    </button>
                                                </div>
                                            </form></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
