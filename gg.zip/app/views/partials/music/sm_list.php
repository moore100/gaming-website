<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("music/add");
$can_edit = ACL::is_allowed("music/edit");
$can_view = ACL::is_allowed("music/view");
$can_delete = ACL::is_allowed("music/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <div ><?php 
                        if(!empty($records)){?>
                        <div class="">
                            <div class="row">
                                <?php 
                                $counter =  0;
                                foreach($records as $data){
                                $rec_id = (!empty($data['id']) ? urlencode($data['id']):null);
                                $counter ++;?>
                                <div class="col-12">
                                    <div class="row py-3 <?php if(($counter%2) == 1){?>stripe-hover<?php } ?> mrad-hover">
                                        <div class="col-md-1 col-2 mrad-td-cover">
                                            <img class="rounded shadow-sm" height="35px" width="35px" src="<?php print_link(set_img_src($data['cover'],35,35))?>"/>
                                            </div>
                                            <div class="col mrad-td-title">
                                                <?php echo $data['title']; ?>
                                                <div class="d-block d-sm-none mb-2 ">
                                                    <?php if(!empty($data['artist'])){ echo $data['artist'];} if(!empty($data['album'])) { echo '--'; echo $data['album'];} if(!empty($data['role'])){ echo '--'; echo $data['role']; }?>
                                                </div>
                                                <div class="d-block d-sm-none">
                                                    <a class="icon-control-play pl-0 btn shadow-0" onclick="playMedia('<?php print_link($data['audio'])?>' , '<?php print_link(set_img_src($data['cover'],200,200));?>' , '<?php echo $data['title'] ?>')"></a>
                                                    <span class="dropdown">
                                                        <a class="btn" data-toggle="dropdown" type="button"><i class="icon-options"></i></a>
                                                        <div class="dropdown-menu border-0 shadow">
                                                            <div class="small">
                                                                <a class="dropdown-item text-muted" href="">
                                                                    <i class="icon-heart mr-2"></i> Heart
                                                                </a>
                                                                <?php if(!empty($data['album'])){ ?>
                                                                <a class="dropdown-item text-muted" href="<?php print_link("music/view_album/album/$data[album]");?>">
                                                                    <i class="icon-microphone mr-2"></i> view album
                                                                </a>
                                                                <?php } ?>
                                                                <?php if(!empty($data['artist'])){ ?>
                                                                <a class="dropdown-item text-muted" href="<?php print_link("music/view_artist/artist/$data[artist]");?>">
                                                                    <i class="icon-user mr-2"></i> view artist
                                                                </a>
                                                                <?php } ?>
                                                                <a class="dropdown-item text-muted page-modal" href="<?php print_link("music/sm_view/$data[id]");?>">
                                                                    <i class="icon-docs mr-2"></i> properties
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-2 mrad-td-control">
                                                <div class="d-sm-block d-none">
                                                    <a class="icon-control-play btn shadow-0" onclick="playMedia('<?php print_link($data['audio'])?>' , '<?php print_link(set_img_src($data['cover'],200,200));?>' , '<?php echo $data['title'] ?>')"></a>
                                                    <span class="dropdown">
                                                        <a class="btn" data-toggle="dropdown" type="button"><i class="icon-options"></i></a>
                                                        <div class="dropdown-menu border-0 shadow">
                                                            <div class="small">
                                                                <a class="dropdown-item text-muted" href="">
                                                                    <i class="icon-heart mr-2"></i> Heart
                                                                </a>
                                                                <?php if(!empty($data['album'])){ ?>
                                                                <a class="dropdown-item text-muted mrad-td-album" href="<?php print_link("music/view_album/album/$data[album]");?>">
                                                                    <i class="icon-microphone mr-2"></i> view album
                                                                </a>
                                                                <?php } ?>
                                                                <?php if(!empty($data['artist'])){ ?>
                                                                <a class="dropdown-item text-muted mrad-td-artist" href="<?php print_link("music/view_artist/artist/$data[artist]");?>">
                                                                    <i class="icon-user mr-2"></i> view artist
                                                                </a>
                                                                <?php } ?>
                                                                <a class="dropdown-item text-muted page-modal mrad-td-property" href="<?php print_link("music/sm_view/$data[id]");?>">
                                                                    <i class="icon-info mr-2"></i> properties
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-2 d-none d-sm-block text-truncate mrad-td-artist">
                                                <?php if(!empty($data['artist'])) { echo $data['artist']; } else { echo 'Unknown artist' ;}?>
                                            </div>
                                            <div class="col-2 d-none d-md-block text-truncate mrad-td-album">
                                                <?php if(!empty($data['album'])) { echo $data['album']; } else { echo 'Unknown album' ;}?>
                                            </div>
                                            <div class="col-2 d-none d-md-block text-truncate mrad-td-role">
                                                <?php if(!empty($data['role'])) { echo $data['role']; } else { echo 'Unknown role' ;}?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php 
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                            }
                        ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
