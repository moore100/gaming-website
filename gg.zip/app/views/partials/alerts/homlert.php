<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("alerts/add");
$can_edit = ACL::is_allowed("alerts/edit");
$can_view = ACL::is_allowed("alerts/view");
$can_delete = ACL::is_allowed("alerts/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <h4 ><?php 
                        if(!empty($records)){?>
                        <div class="">
                            <div class="scroll-resp">
                                <?php 
                                $counter =  0;
                                shuffle($records);
                                foreach($records as $data){
                                $rec_id = (!empty($data['id']) ? urlencode($data['id']):null);
                                $counter ++;?>
                                <div class="col-lg-4 col-md-6 col-sm-6 col-11 mb-3 p-2 cardPPl<?php echo $rec_id?>">
                                    <a class="d-block col-12 p-0 rounded o-none shadow-sm" href="#">
                                        <div class="alert-warning card" style="height:50px;"><?php echo SITE_LOGO;?></div>
                                        <div class="uk-overlay-primary alert-warning p-2 uk-position-bottom uk-light">
                                            <span class="small">
                                                <?php echo $data['headline'];?>
                                            <i class="icon-tag "></i></i><?php echo $data['tag'];?>
                                            <i class="icon-calendar "></i><?php echo human_datetime($data['date']); ?>
                                        </span>
                                    </div>
                                </a>
                            </div>
                            <?php 
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                    }
                ?></h4>
            </div>
        </div>
    </div>
</div>
<div  class="">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-12 comp-grid">
            </div>
        </div>
    </div>
</div>
</section>
