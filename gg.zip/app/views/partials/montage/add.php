<?php
$comp_model = new SharedController;
$page_element_id = "add-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="add"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-7 col-sm-12 theme-bw shadow mb-5 mb-sm-0 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="bg-light p-3 animated fadeIn page-content">
                        <form id="montage-add-form" role="form" novalidate enctype="multipart/form-data" class="form page-form form-vertical needs-validation" action="<?php print_link("montage/add?csrf_token=$csrf_token") ?>" method="post">
                            <div>
                                <div class="form-group ">
                                    <div id="ctrl-ytlink-holder" class="">
                                        <input id="ctrl-ytlink"  value="<?php  echo $this->set_field_value('ytlink',""); ?>" type="text" placeholder="Enter Ytlink"  required="" name="ytlink"  class="form-control " />
                                        </div>
                                    </div>
                                    <input id="ctrl-date"  value="<?php  echo $this->set_field_value('date',datetime_now()); ?>" type="hidden" placeholder="Enter Date"  name="date"  class="form-control " />
                                        <div class="form-group ">
                                            <div id="ctrl-posted_by-holder" class="">
                                                <input id="ctrl-posted_by"  value="<?php  echo $this->set_field_value('posted_by',""); ?>" type="text" placeholder="Enter Posted By"  required="" name="posted_by"  class="form-control " />
                                                </div>
                                            </div>
                                            <div class="form-group ">
                                                <div id="ctrl-banner-holder" class="">
                                                    <div class="dropzone required" input="#ctrl-banner" fieldname="banner"    data-multiple="false" dropmsg="THUMBNAIL"    btntext="Browse" filesize="5" maximum="1">
                                                        <input name="banner" id="ctrl-banner" required="" class="dropzone-input form-control" value="<?php  echo $this->set_field_value('banner',""); ?>" type="text"  />
                                                            <!--<div class="invalid-feedback animated bounceIn text-center">Please a choose file</div>-->
                                                            <div class="dz-file-limit animated bounceIn text-center text-danger"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group ">
                                                    <div id="ctrl-headline-holder" class="">
                                                        <input id="ctrl-headline"  value="<?php  echo $this->set_field_value('headline',""); ?>" type="text" placeholder="Enter Headline"  required="" name="headline"  class="form-control " />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-submit-btn-holder text-center mt-3">
                                                    <div class="form-ajax-status"></div>
                                                    <button class="btn btn-primary" type="submit">
                                                        <i class="icon-paper-plane"></i>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
