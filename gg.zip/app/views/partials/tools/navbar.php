<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("tools/add");
$can_edit = ACL::is_allowed("tools/edit");
$can_view = ACL::is_allowed("tools/view");
$can_delete = ACL::is_allowed("tools/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-sm-12 p-0 comp-grid">
                    <div ><div class="">
                        <!--sidenav brand-->
                        <?php $set_id = '1'?>
                        <div class="mb-3 mt-2 nav-item d-flex justify-content-between align-items-start">
                            <a class="btn p-0 shadow-0">
                                <span class="icon-menu sidenav-toggle ml-1 mr-3 text-muted"></span> 
                                <span class="text-theme menu-lable text-capitalize" id="navbrand"></span>
                            </a>
                        </div>
                        <!--sidenav searchbar-->
                        <div class="mb-4 nav-item ">
                            <form class="menu-lable mrad-search p-1" action="<?php print_link('blogs/all'); ?>" method="get">
                                <div class="input-group">
                                    <span class="input-group-append p-2" uk-search-icon></span>
                                    <input autocomplete="off" class="form-control border-0 text-auto" style="background:rgba(0,0,0,0);" type="search" placeholder="Search..." name="search">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 p-0 comp-grid">
                        <div ><div class="">
                            <!--sidenav content-->
                            <div class="navbar-nav mb-4">
                                <a class="nav-item " title="home" href="<?php print_link('Home#');?>">
                                    <i class="icon-home mr-2"></i> <span class="menu-lable">Home</span>
                                </a>
                                <a class="nav-item " title="browse" href="<?php print_link('video/all');?>">
                                    <i class="icon-social-youtube mr-2"></i> <span class="menu-lable">Lounge Videos</span>
                                </a> 
                                <a class="nav-item " title="artists" href="<?php print_link('clans/homeclans');?>">
                                    <i class="icon-ghost  mr-2"></i> <span class="menu-lable">Clans</span>
                                </a>
                                <a class="nav-item " title="albums" href="<?php print_link('content_creators/creators');?>">
                                    <i class="icon-people  mr-2"></i> <span class="menu-lable">Content Creators</span>
                                </a>
                            </div>
                            <!--sidenav content-->
                            <div class="navbar-nav mb-4">
                                <div class="mrad-sidenav-title mb-3 nav-item"><span class="menu-lable text-theme">get Dubs</span></div>
                                <a class="nav-item " title="repository" href="<?php print_link('blogs/all');?>">
                                    <i class="icon-feed   mr-2"></i> <span class="menu-lable">Blogs</span>
                                </a> 
                                <a class="nav-item " title="play history" href="<?php print_link('video/all');?>">
                                    <i class="icon-social-youtube  mr-2"></i> <span class="menu-lable">Videos</span>
                                </a>
                                <a class="nav-item " title="play history" href="<?php print_link('montage/all');?>">
                                    <i class="icon-film   mr-2"></i> <span class="menu-lable">Community Montages</span>
                                </a>
                                <a class="nav-item " title="settings" href="<?php print_link("setting/view/$set_id")?>">
                                    <i class="icon-settings mr-2"></i> <span class="menu-lable">Settings</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4 comp-grid">
                    <?php $rec_count = $comp_model->getcount_collapse();  ?>
                    <a class="animated  record-count d-none"  href="<?php print_link("") ?>">
                        <div class="row">
                            <div class="col-2">
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">collapse</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                    <?php $rec_count = $comp_model->getcount_loop();  ?>
                    <a class="animated  record-count d-none"  href="<?php print_link("setting/") ?>">
                        <div class="row">
                            <div class="col-2">
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">loop</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                    <div ><?php 
                        $mradcollapse = $comp_model->getcount_collapse();
                        $mradloop = $comp_model->getcount_loop();
                        ?>
                        <?php if($mradcollapse == 'true') { ?>
                        <script>
                            $(".mrad-sidenav").toggleClass("col-lg-3 col-md-4 mrad-col");
                            $(".mrad-sidenav .menu-lable").addClass("d-none");
                        </script>
                        <?php } ?>
                        <audio class="d-none" id="audio" autoplay="" <?php if($mradloop == 'true') { ?> loop <?php } ?> controls>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
