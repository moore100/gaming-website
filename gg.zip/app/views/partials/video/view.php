<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("video/add");
$can_edit = ACL::is_allowed("video/edit");
$can_view = ACL::is_allowed("video/view");
$can_delete = ACL::is_allowed("video/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <h4 ><div class="col-12 p-md-4">
                        <div class="row">
                            <div class="col-md-12 col-12 mb-3 comp-grid">
                                <div class="theme-bw rounded shadow text-white">
                                    <div class="uk-overlay py-5 uk-overlay-cover">
                                        <div class="embed-responsive embed-responsive-16by9">
                                            <iframe class="embed-responsive-item" src="<?php echo $data['links'];?>" allowfullscreen></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 mb-3 comp-grid">
                                <div class="fill d-flex align-items-end">
                                    <span>
                                        <span class="d-block mb-2">
                                            <div class="col">
                                                <span class=" mrad-sidenav-title">Sponsored Content Creators</span>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="">
                                                    <?php $this->render_page('content_creators/cc?limit_count=12');?>
                                                </div>
                                            </div>
                                            <span class="mr-2 text-white"><h1 class="text-white"><?php echo $data['headline'] ?></h1>  <i class="icon-user-following "></i><?php echo $data['date'] ?></span>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <span class=" mrad-sidenav-title">More</span>
                    </div>
                    <div class="col-12">
                        <div class="">
                            <?php $this->render_page('video/loungevids?limit_count=20');?>
                        </div>
                    </div>
                    <div id="disqus_thread"></div>
                    <script>
                        /**
                        *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
                        *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
                        /*
                        var disqus_config = function () {
                        this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
                        this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
                        };
                        */
                        (function() { // DON'T EDIT BELOW THIS LINE
                        var d = document, s = d.createElement('script');
                        s.src = 'https://gamer-lounge-ke.disqus.com/embed.js';
                        s.setAttribute('data-timestamp', +new Date());
                        (d.head || d.body).appendChild(s);
                        })();
                    </script>
                <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript></h4>
            </div>
        </div>
    </div>
</div>
<div  class="">
    <div class="container">
        <div class="row ">
            <div class="col-md-12 comp-grid">
            </div>
        </div>
    </div>
</div>
</section>
