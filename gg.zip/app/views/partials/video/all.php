<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("video/add");
$can_edit = ACL::is_allowed("video/edit");
$can_view = ACL::is_allowed("video/view");
$can_delete = ACL::is_allowed("video/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <h4 ><div class="">
                        <div class="d-flex justify-content-between align-items-end">
                            <a class="btn p-0" onclick="goback()"><i class="icon-arrow-left"></i></a>
                            <div class="dropdown" >
                                <a class="" type="button" data-toggle="dropdown">Sponsors<i class="icon-people ml-3 alert-danger rounded-circle p-2"></i></a>
                                <div class="dropdown-menu shadow border-0">
                                    <a class="dropdown-item" href="https://jiwe.studio/">
                                        <i class="icon-people ml-3 alert-danger rounded-circle p-2"></i> Jiwe Studios
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 text-theme p-0 display-5 pt-3 text-truncate" id="gamelounge">
                            GAMER LOUNGE KE
                        </div>
                        <div class="col-12 p-0">
                            <a class="btn btn-sm border-left">
                                <i class="icon-shuffle mr-1"></i>Gamerlounge Videos
                            </a>
                            <a class="btn btn-sm">
                                <i class="icon-drop mr-1"></i> Sort by 
                                <span class="text-muted bold">A</span> - <span class="text-muted bold">Z</span>
                            </a>
                            <a class="dropdown">
                                <a class="btn btn-sm mrad-btn" data-toggle="dropdown">
                                    <i class="icon-arrow-down"></i>
                                </a>
                                <div class="dropdown-menu shadow border-0">
                                    <a class="dropdown-item">
                                        <i class="icon-grid mr-2"></i> Option One
                                    </a>
                                    <a class="dropdown-item" href="#">
                                        <i class="icon-grid mr-2"></i> Switch Grid
                                    </a>
                                </div>
                            </a>
                            <span class="d-none d-md-none d-sm-inline">
                                <form class="uk-search uk-search-default">
                                    <span uk-search-icon></span>
                                    <input class="uk-search-input" placeholder="Search" name="search" type="search" autocomplete="off"></input>
                                </form>
                            </span>
                        </div>
                    </div>
                    <?php 
                    if(!empty($records)){?>
                    <div class="">
                        <div class="row">
                            <?php 
                            $counter =  0;
                            shuffle($records);
                            foreach($records as $data){
                            $rec_id = (!empty($data['id']) ? urlencode($data['id']):null);
                            $counter ++;?>
                            <div class="col-md-6 col-sm-6 col-12 mb-3 p-2 cardPPl<?php echo $rec_id?>">
                                <a class="d-block col-12 p-0 rounded o-none shadow-sm" href="<?php print_link("video/view/$rec_id")?>">
                                    <img class="fill" src="<?php print_link(set_img_src($data['banner'], 600,350))?>">
                                        <div class="uk-overlay-primary alert-danger p-2 uk-position-bottom uk-light">
                                            <span class="d-block  text-white">
                                                <?php echo $data['headline'];?>
                                            </span>
                                            <span class="small">
                                                <i class="icon-control-play "></i> &nbsp
                                                <i class="icon-calendar "></i>&nbsp<?php echo $data['date']; ?>
                                            </span>
                                        </div>
                                    </a>
                                </div>
                                <?php 
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                        }
                    ?></h4>
                </div>
            </div>
        </div>
    </div>
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                </div>
            </div>
        </div>
    </div>
</section>
