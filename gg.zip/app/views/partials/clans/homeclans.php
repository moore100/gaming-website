<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("clans/add");
$can_edit = ACL::is_allowed("clans/edit");
$can_view = ACL::is_allowed("clans/view");
$can_delete = ACL::is_allowed("clans/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <h4 ><div class="">
                        <div class="d-flex justify-content-between align-items-end">
                            <a class="btn p-0" onclick="goback()"><i class="icon-arrow-left"></i></a>
                            <div class="dropdown" >
                                <a class="" type="button" data-toggle="dropdown">Sponsors<i class="icon-people ml-3 alert-danger rounded-circle p-2"></i></a>
                                <div class="dropdown-menu shadow border-0">
                                    <a class="dropdown-item" href="https://jiwe.studio/">
                                        <i class="icon-people ml-3 alert-danger rounded-circle p-2"></i> Jiwe Studios
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 text-theme p-0 display-5 pt-3 text-truncate" id="gamelounge">
                            GAMER LOUNGE KE
                        </div>
                        <div class="col-12 p-0">
                            <a class="btn btn-sm border-left">
                                <i class="icon-shuffle mr-1"></i>Clans
                            </a>
                            <a class="btn btn-sm">
                                <i class="icon-drop mr-1"></i> Sort by 
                                <span class="text-muted bold">A</span> - <span class="text-muted bold">Z</span>
                            </a>
                            <a class="dropdown">
                                <a class="btn btn-sm mrad-btn" data-toggle="dropdown">
                                    <i class="icon-arrow-down"></i>
                                </a>
                                <div class="dropdown-menu shadow border-0">
                                    <a class="dropdown-item">
                                        <i class="icon-grid mr-2"></i> Option One
                                    </a>
                                    <a class="dropdown-item" href="#">
                                        <i class="icon-grid mr-2"></i> Switch Grid
                                    </a>
                                </div>
                            </a>
                            <span class="d-none d-md-none d-sm-inline">
                                <form class="uk-search uk-search-default">
                                    <span uk-search-icon></span>
                                    <input class="uk-search-input" placeholder="Search" name="search" type="search" autocomplete="off"></input>
                                </form>
                            </span>
                        </div>
                    </div></h4>
                </div>
                <div class="col-md-12 comp-grid">
                    <h4 ><?php 
                        if(!empty($records)){?>
                        <div class="">
                            <div class="row">
                                <?php 
                                $counter =  0;
                                foreach($records as $data){
                                $rec_id = (!empty($data['id']) ? urlencode($data['id']):null);
                                $counter ++;?>
                                <div class="col-lg-3 col-md-4 parent col-sm-4 col-6 mb-3 comp-grid">
                                    <a class="fill no-d p-md-3 p-3 d-block theme-1gt rounded shadow-sm">
                                        <div class="py-md-3 uk-overlay-cover uk-light">
                                            <img class="shadow rounded-circle" src="<?php print_link(set_img_src($data['logo'],50,50));?>"/>
                                                <h4 class="d-block bold text-truncate"><?php echo $data['name'];?></h4>
                                                <small class="text-truncate"><i class="icon-chart "></i>&nbsp<?php echo $data['rank'];?></small>
                                                <small class="text-truncate"><i class="icon-trophy "></i>&nbsp<?php echo $data['wins'];?></small>
                                                <small class="text-truncate">  <i class="icon-game-controller "></i>&nbsp<?php echo $data['games'];?></small>
                                                <?php
                                                if($data['rank'] == 1){
                                                echo'&#x1F525';
                                                }?>
                                            </div>
                                        </a>
                                    </div>
                                    <?php
                                    }
                                    }
                                ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div  class="">
                    <div class="container-fluid">
                        <div class="row ">
                            <div class="col-md-12 comp-grid">
                            </div>
                        </div>
                    </div>
                </div>
            </section>
