<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("clans/add");
$can_edit = ACL::is_allowed("clans/edit");
$can_view = ACL::is_allowed("clans/view");
$can_delete = ACL::is_allowed("clans/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <h4 ><?php 
                        if(!empty($records)){?>
                        <div class="">
                            <div class="row">
                                <?php 
                                $counter =  0;
                                foreach($records as $data){
                                $rec_id = (!empty($data['id']) ? urlencode($data['id']):null);
                                $counter ++;?>
                                <div class="col-lg-3 col-md-4 parent col-sm-4 col-6 mb-3 comp-grid">
                                    <a class="fill no-d p-md-3 p-3 d-block theme-1gt rounded shadow-sm">
                                        <div class="py-md-3 uk-overlay-cover uk-light">
                                            <img class="shadow rounded-circle" src="<?php print_link(set_img_src($data['logo'],50,50));?>"/>
                                                <h4 class="d-block bold text-truncate"><?php echo $data['name'];?></h4>
                                                <small class="text-truncate"><i class="icon-chart "></i><?php echo $data['rank'];?></small>
                                                <small class="text-truncate"><i class="icon-trophy "></i><?php echo $data['wins'];?></small>
                                                <small class="text-truncate">  <i class="icon-game-controller "></i><?php echo $data['games'];?></small>
                                                <?php
                                                if($data['rank'] == 1){
                                                echo'&#x1F525';
                                                }?>
                                            </div>
                                        </a>
                                    </div>
                                    <?php
                                    }
                                    }
                                ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div  class="">
                    <div class="container-fluid">
                        <div class="row ">
                            <div class="col-md-12 comp-grid">
                            </div>
                        </div>
                    </div>
                </div>
            </section>
