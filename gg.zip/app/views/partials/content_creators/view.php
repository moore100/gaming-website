<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("content_creators/add");
$can_edit = ACL::is_allowed("content_creators/edit");
$can_view = ACL::is_allowed("content_creators/view");
$can_delete = ACL::is_allowed("content_creators/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <h4 ><div class="col-12 p-md-4">
                        <div class="row">
                            <div class="col-md-4 col-8 mb-3 comp-grid">
                                <div class="theme-bw rounded shadow text-white">
                                    <div class="uk-overlay py-5 uk-overlay-cover">
                                        <?php html:: page_img($data['photo'],500,500,1,'','fill rounded-circle shadow');?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 mb-3 comp-grid">
                                <div class="fill d-flex align-items-end">
                                    <span>
                                        <span class="d-block mb-2">
                                            <div class="col-md-8">
                                                <div class="">
                                                    <?php $this->render_page('banner/homebanner?limit_count=1');?>
                                                </div>
                                            </div>
                                            <span class="mr-2"><h1><?php echo $data['name'] ?></h1></span>
                                        </span>
                                        <span class="d-block mb-2">
                                            <p>
                                                <?php echo $data['description'] ?>
                                            </p>
                                            <button class="btn btn-danger border btn-lg" href="<?php echo $data['youtube'];?>"><i class="icon-bell "></i>Subscribe</button>
                                        </span>
                                        <span class="d-block mt-3">
                                            <a href= "<?php echo $data['facebook'];?>" class="btn border rounded">
                                                <i class="icon-social-facebook" style="color:blue;"></i>
                                                <span class="d-none d-sm-inline">Facebook</span>
                                            </a>
                                            <a href="<?php echo $data['youtube']; ?>" class="btn border rounded">
                                                <i class="icon-social-twitter " style="color:blue;"></i>
                                                <span class="d-none d-sm-inline"> 
                                                Twitter</span>
                                            </a>
                                            <a href=" <?php echo $data['instagram'];?>" class="btn border rounded">
                                                <i class="icon-social-instagram"  style="color:magenta;"></i>
                                                <span class="d-none d-sm-inline">
                                                Instagram</span>
                                            </a>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <span class=" mrad-sidenav-title">Game lounge content creators</span>
                    </div>
                    <div class="col-12">
                        <div class="">
                            <?php $this->render_page('content_creators/cc?limit_count=6');?>
                        </div>
                    </div>
                    <link href="<?php echo SITE_ADDR;?>plugins/css/youram-simple.min.css" rel="stylesheet" type="text/css">
                        <script src="<?php echo SITE_ADDR;?>plugins/js/youram-simple.min.js"></script>
                        <!--YouRam Container-->
                        <div id="yram" class="youram-simple"></div>
                        <!-- ends -->
                        <br><br>
                        </div>
                        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                            <?php
                            echo ' 
                            <script>
                                $(document).ready(function(){   
                                $(".youram-simple").youramSimple({
                                apiKey                  :"'.$data['api'].'",    
                                sourceLink              :"'.$data['youtube'].'",    
                                maxResults              :"10",
                                videoDisplayMode        :"popup",                                       
                                });
                                });
                            </script>';?>
                        </div></h4>
                    </div>
                </div>
            </div>
        </div>
        <div  class="">
            <div class="container">
                <div class="row ">
                    <div class="col-md-12 comp-grid">
                    </div>
                </div>
            </div>
        </div>
    </section>
