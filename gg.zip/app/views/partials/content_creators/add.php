<?php
$comp_model = new SharedController;
$page_element_id = "add-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="add"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">Add New Content Creators</h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="bg-light p-3 animated fadeIn page-content">
                        <form id="content_creators-add-form" role="form" novalidate enctype="multipart/form-data" class="form page-form form-vertical needs-validation" action="<?php print_link("content_creators/add?csrf_token=$csrf_token") ?>" method="post">
                            <div>
                                <div class="form-group ">
                                    <div id="ctrl-logo-holder" class="">
                                        <div class="dropzone required" input="#ctrl-logo" fieldname="logo"    data-multiple="false" dropmsg="Choose files or drag and drop files to upload"    btntext="Browse" filesize="5" maximum="1">
                                            <input name="logo" id="ctrl-logo" required="" class="dropzone-input form-control" value="<?php  echo $this->set_field_value('logo',""); ?>" type="text"  />
                                                <!--<div class="invalid-feedback animated bounceIn text-center">Please a choose file</div>-->
                                                <div class="dz-file-limit animated bounceIn text-center text-danger"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <div id="ctrl-name-holder" class="">
                                            <input id="ctrl-name"  value="<?php  echo $this->set_field_value('name',""); ?>" type="text" placeholder="Enter Name"  required="" name="name"  class="form-control " />
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-6">
                                                <div id="ctrl-facebook-holder" class="">
                                                    <input id="ctrl-facebook"  value="<?php  echo $this->set_field_value('facebook',""); ?>" type="url" placeholder="Enter Facebook"  name="facebook"  class="form-control " />
                                                    </div>
                                                </div>
                                                <div class="form-group col-6">
                                                    <div id="ctrl-instagram-holder" class="">
                                                        <input id="ctrl-instagram"  value="<?php  echo $this->set_field_value('instagram',""); ?>" type="url" placeholder="Enter Instagram"  name="instagram"  class="form-control " />
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-6">
                                                        <div id="ctrl-youtube-holder" class="">
                                                            <input id="ctrl-youtube"  value="<?php  echo $this->set_field_value('youtube',""); ?>" type="url" placeholder="Enter Youtube"  name="youtube"  class="form-control " />
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-6">
                                                            <div id="ctrl-twitter-holder" class="">
                                                                <input id="ctrl-twitter"  value="<?php  echo $this->set_field_value('twitter',""); ?>" type="url" placeholder="Enter Twitter"  name="twitter"  class="form-control " />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group ">
                                                            <div id="ctrl-photo-holder" class="">
                                                                <div class="dropzone required" input="#ctrl-photo" fieldname="photo"    data-multiple="false" dropmsg="Choose files or drag and drop files to upload"    btntext="Browse" extensions=".jpg,.png,.gif,.jpeg" filesize="5" maximum="1">
                                                                    <input name="photo" id="ctrl-photo" required="" class="dropzone-input form-control" value="<?php  echo $this->set_field_value('photo',""); ?>" type="text"  />
                                                                        <!--<div class="invalid-feedback animated bounceIn text-center">Please a choose file</div>-->
                                                                        <div class="dz-file-limit animated bounceIn text-center text-danger"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group ">
                                                                <div id="ctrl-description-holder" class="">
                                                                    <textarea placeholder="Enter Description" id="ctrl-description"  required="" rows="5" name="description" class=" form-control"><?php  echo $this->set_field_value('description',""); ?></textarea>
                                                                    <!--<div class="invalid-feedback animated bounceIn text-center">Please enter text</div>-->
                                                                </div>
                                                            </div>
                                                            <input id="ctrl-date"  value="<?php  echo $this->set_field_value('date',datetime_now()); ?>" type="hidden" placeholder="Enter Date"  name="date"  class="form-control " />
                                                                <input id="ctrl-api"  value="<?php  echo $this->set_field_value('api',"AIzaSyCbxkNthzdyF_iYk85qSs9KSrtnroNq8qw"); ?>" type="hidden" placeholder="Enter Api"  name="api"  class="form-control " />
                                                                    <div class="form-group ">
                                                                        <div id="ctrl-twitch-holder" class="">
                                                                            <input id="ctrl-twitch"  value="<?php  echo $this->set_field_value('twitch',""); ?>" type="text" placeholder="Enter Twitch"  required="" name="twitch"  class="form-control " />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group form-submit-btn-holder text-center mt-3">
                                                                        <div class="form-ajax-status"></div>
                                                                        <button class="btn btn-primary" type="submit">
                                                                            Submit
                                                                            <i class="icon-paper-plane"></i>
                                                                        </button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
