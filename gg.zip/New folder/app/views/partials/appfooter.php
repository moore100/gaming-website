
<?php 
	Html ::  page_js('uikit.min.js');
    Html ::  page_js('uikit-icons.min.js');
?>