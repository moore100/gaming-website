<?php $this->render_page("tools/sett_control/1");?>
<?php $this->render_view('appnav.php');?>
<div class="col-12">
<div class="row">
    <div class="mrad-sidenav col-lg-3 col-md-4 col-1 skinned d-none d-sm-block">
        <div class="mother">
            <?php $this->render_page('tools/navbar')?>
        </div>
    </div>
    <div class="mrad-body bg theme col-lg col-md col p-0">