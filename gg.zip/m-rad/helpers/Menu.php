<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbartopleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => ''
		),
		
		array(
			'path' => 'category', 
			'label' => 'Category', 
			'icon' => ''
		),
		
		array(
			'path' => 'heart', 
			'label' => 'Heart', 
			'icon' => ''
		),
		
		array(
			'path' => 'music', 
			'label' => 'Music', 
			'icon' => ''
		),
		
		array(
			'path' => 'playlist', 
			'label' => 'Playlist', 
			'icon' => ''
		),
		
		array(
			'path' => 'users', 
			'label' => 'Users', 
			'icon' => ''
		),
		
		array(
			'path' => 'tools', 
			'label' => 'Tools', 
			'icon' => ''
		),
		
		array(
			'path' => 'page', 
			'label' => 'Page', 
			'icon' => ''
		),
		
		array(
			'path' => 'subpage', 
			'label' => 'Subpage', 
			'icon' => ''
		),
		
		array(
			'path' => 'setting', 
			'label' => 'Setting', 
			'icon' => ''
		),
		
		array(
			'path' => 'tools', 
			'label' => 'Tools', 
			'icon' => ''
		)
	);
		
	
	
			public static $theme = array(
		array(
			"value" => "white", 
			"label" => "White", 
		),
		array(
			"value" => "light", 
			"label" => "Light", 
		),
		array(
			"value" => "dark", 
			"label" => "Dart", 
		),
		array(
			"value" => "black", 
			"label" => "Black", 
		),);
		
			public static $color = array(
		array(
			"value" => "#FF0039", 
			"label" => "Default", 
		),
		array(
			"value" => "#9954BB", 
			"label" => "M-Indigo", 
		),
		array(
			"value" => "#FF7518", 
			"label" => "M-Orange", 
		),
		array(
			"value" => "#2780E3", 
			"label" => "M-Blue", 
		),
		array(
			"value" => "#3FB618", 
			"label" => "M-green", 
		),
		array(
			"value" => "#20c997", 
			"label" => "M-teal", 
		),);
		
}