<?php 

/**
 * SharedController Controller
 * @category  Controller / Model
 */
class SharedController extends BaseController{
	
	/**
     * music_artist_option_list Model Action
     * @return array
     */
	function music_artist_option_list($search_text = null){
		$arr = array();
		if(!empty($search_text)){
			$db = $this->GetModel();
			$sqltext = "SELECT  DISTINCT title AS value,title AS label FROM music WHERE title LIKE ? LIMIT 0,10" ;
			$queryparams = array("%$search_text%");
			$arr = $db->rawQuery($sqltext, $queryparams);
		}
		return $arr;
	}

	/**
     * music_role_option_list Model Action
     * @return array
     */
	function music_role_option_list($search_text = null){
		$arr = array();
		if(!empty($search_text)){
			$db = $this->GetModel();
			$sqltext = "SELECT  DISTINCT title AS value,title AS label FROM category WHERE title LIKE ? LIMIT 0,10" ;
			$queryparams = array("%$search_text%");
			$arr = $db->rawQuery($sqltext, $queryparams);
		}
		return $arr;
	}

	/**
     * music_role_option_list_2 Model Action
     * @return array
     */
	function music_role_option_list_2($search_text = null){
		$arr = array();
		if(!empty($search_text)){
			$db = $this->GetModel();
			$sqltext = "SELECT  DISTINCT role AS value,role AS label FROM music WHERE role LIKE ? LIMIT 0,10" ;
			$queryparams = array("%$search_text%");
			$arr = $db->rawQuery($sqltext, $queryparams);
		}
		return $arr;
	}

	/**
     * getcount_collapse Model Action
     * @return Value
     */
	function getcount_collapse(){
		$db = $this->GetModel();
		$sqltext = "SELECT  s.auto_collapse FROM setting AS s";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_loop Model Action
     * @return Value
     */
	function getcount_loop(){
		$db = $this->GetModel();
		$sqltext = "SELECT  s.autoplay FROM setting AS s WHERE  (s.id  =1 )";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

}
