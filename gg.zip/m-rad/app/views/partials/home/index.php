<?php 
$page_id = null;
$comp_model = new SharedController;
$current_page = $this->set_current_page_link();
?>
<div>
    <div  class="pb-5 mb-4">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <div  class="">
                        <div class="container-fluid">
                            <div class="row ">
                                <div class="col-12 p-0 mb-2 ">
                                    <div class="col-12 banner"  uk-sticky="media: 574"  id=""><div class="">
                                        <div class="d-flex justify-content-between align-items-end">
                                            <a class="btn p-0" onclick="goback()"><i class="icon-arrow-left"></i></a>
                                            <div class="dropdown" >
                                                <a class="" type="button" data-toggle="dropdown">Add <i class="ml-2" uk-icon="plus"></i></a>
                                                <div class="dropdown-menu shadow border-0">
                                                    <a class="dropdown-item" href="<?php print_link("music/pc_add");?>">
                                                        <i class="icon-music-tone mr-2"></i> New Track
                                                    </a>
                                                    <a class="dropdown-item">
                                                        <i class="icon-folder-alt mr-2"></i> Category
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 text-theme p-0 display-5 pt-3 text-truncate">
                                            Home
                                        </div>
                                        <div class="col-12 p-0">
                                            <a class="btn btn-sm border-left">
                                                <i class="icon-shuffle mr-1"></i> Shuffle (24)
                                            </a>
                                            <a class="btn btn-sm">
                                                <i class="icon-drop mr-1"></i> Sort by 
                                                <span class="text-muted bold">A</span> - <span class="text-muted bold">Z</span>
                                            </a>
                                            <a class="dropdown">
                                                <a class="btn btn-sm mrad-btn" data-toggle="dropdown">
                                                    <i class="icon-arrow-down"></i>
                                                </a>
                                                <div class="dropdown-menu shadow border-0">
                                                    <a class="dropdown-item">
                                                        <i class="icon-grid mr-2"></i> Option One
                                                    </a>
                                                    <a class="dropdown-item" href="#">
                                                        <i class="icon-grid mr-2"></i> Switch Grid
                                                    </a>
                                                </div>
                                            </a>
                                            <span class="d-none d-md-none d-sm-inline">
                                                <form class="uk-search uk-search-default">
                                                    <span uk-search-icon></span>
                                                    <input class="uk-search-input" placeholder="Search" name="search" type="search" autocomplete="off"></input>
                                                </form>
                                            </span>
                                        </div>
                                    </div></div>
                                </div>
                                <div class="col-sm-12 p-0 mb-md-4 comp-grid">
                                    <div ><!--top track-->
                                        <div class="col-12">
                                            <div class="">
                                                <?php $this->render_page('subpage/latest?limit_count=6');?>
                                            </div>
                                        </div>
                                        <!--playlist-->
                                        <div class="col-12">
                                            <div class="row mb-2">
                                                <div class="col">
                                                    <span class=" mrad-sidenav-title">Playlist</span>
                                                </div>
                                                <div class="col p-0 text-right">
                                                    <a class="btn text-auto" href="<?php print_link('page/playlist');?>">
                                                    <small>More</small><i class="icon-arrow-right ml-2 small"></i></a>
                                                </div>
                                            </div>
                                            <div class="">
                                                <?php $this->render_page('subpage/playlist?limit_count=6');?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 p-0 section bg mb-3 comp-grid">
                                    <div class="my-3">
                                        <!--album-->
                                        <div class="col-12">
                                            <div class="row mb-2">
                                                <div class="col">
                                                    <span class=" mrad-sidenav-title">Album</span>
                                                </div>
                                                <div class="col p-0 text-right">
                                                    <a class="btn text-auto" href="<?php print_link('page/album');?>">
                                                    <small>More</small><i class="icon-arrow-right ml-2 small"></i></a>
                                                </div>
                                            </div>
                                            <div class="">
                                                <?php $this->render_page('subpage/album');?>
                                            </div>
                                        </div></div>
                                    </div>
                                    <div class="col-sm-12 p-0 comp-grid">
                                        <div ><!--tranding-->
                                            <div class="col-12">
                                                <div class="row mb-2">
                                                    <div class="col">
                                                        <span class=" mrad-sidenav-title">Trending</span>
                                                    </div>
                                                    <div class="col p-0 text-right">
                                                        <a class="btn text-auto" href="<?php print_link('page/track');?>">
                                                        <small>More</small><i class="icon-arrow-right ml-2 small"></i></a>
                                                    </div>
                                                </div>
                                                <div class="">
                                                    <?php $this->render_page('subpage/track?limit_count=6');?>
                                                </div>
                                            </div>
                                            <!--random-->
                                            <div class="col-12">
                                                <div class="row mb-2">
                                                    <div class="col">
                                                        <span class=" mrad-sidenav-title">Recomended</span>
                                                    </div>
                                                    <div class="col p-0 text-right">
                                                        <a class="btn text-auto" href="<?php print_link('page/track');?>">
                                                        <small>More</small><i class="icon-arrow-right ml-2 small"></i></a>
                                                    </div>
                                                </div>
                                                <div class="">
                                                    <?php $this->render_page('subpage/random?limit_count=6');?>
                                                </div>
                                            </div></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
