<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="pb-5">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-12 my-5 ">
                    <div ><div class="col-12 p-md-4">
                        <div class="row">
                            <div class="col-md-4 col-8 mb-3 comp-grid">
                                <div class="theme-bw rounded shadow text-white">
                                    <div class="uk-overlay py-5 uk-overlay-cover">
                                        <?php html:: page_img($data['cover'],500,500,1,'','fill rounded-circle shadow');?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 mb-3 comp-grid">
                                <div class="fill d-flex align-items-end">
                                    <span>
                                        <span class="d-block mb-2 display-5 text-auto">
                                            <span class="mr-2"> <?php echo $data['artist'] ?> </span>
                                        </span>
                                        <span class="d-block mb-2">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium dolores doloribus eligendi eum illo placeat quis repellendus sequi tempore
                                            </p>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium dolores doloribus eligendi eum illo placeat quis repellendus sequi tempore
                                            </p>
                                        </span>
                                        <span class="d-block mt-3">
                                            <a class="btn border rounded">
                                                <i class="icon-control-play mr-2"></i> 
                                                <span class="d-none d-sm-inline">Play All</span>
                                            </a>
                                            <a class="btn border rounded">
                                                <i class="icon-pin mr-2"></i> 
                                                <span class="d-none d-sm-inline"> Pin to tepository</span>
                                            </a>
                                            <a class="btn border rounded">
                                                <i class="icon-heart mr-2"></i>
                                                <span class="d-none d-sm-inline">Heart</span>
                                            </a>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div></div>
                </div>
                <div class="col-md-12 p-0 comp-grid">
                    <div ><div class="col-12 mb-3 text-theme display-5">
                        More of <?php echo $data['artist'];?>
                    </div>
                    <div class="col-12">
                        <style>
                            .td-artist{
                            display:none;
                            }
                        </style>
                        <?php $this->render_page("music/sm_list/album/$data[album]");?>
                    </div></div>
                </div>
            </div>
        </div>
    </div>
</section>
