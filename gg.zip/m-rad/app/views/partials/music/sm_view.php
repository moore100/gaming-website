<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="bg theme">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <div ><div class="col-12 p-4">
                        <div class="row">
                            <div class="col-md-12 mb-3 comp-grid">
                                <div class="fill d-flex align-items-end">
                                    <span>
                                        <span class="d-block mb-2">
                                            <i class="icon-music-tone mr-3"></i> 
                                            <span class="mr-2">Title : <?php echo $data['title'] ?></span>
                                        </span>
                                        <span class="d-block mb-2">
                                            <i class="icon-microphone mr-3"></i>
                                            <span class="mr-2">Album Name: </span>
                                            <?php if(!empty($data['album'])){ ?> <?php echo $data['album'] ?>
                                            <a class="icon-eye" href="<?php print_link("music/view_album/album/$data[album]");?>"></a>
                                            <?php } else { ?> <?php echo 'Uknown Album' ?> <?php } ?>
                                        </span>
                                        <span class="d-block mb-2">
                                            <i class="icon-user-follow mr-3"></i> 
                                            <span class="mr-2">Artist Name: </span>
                                            <?php if(!empty($data['artist'])){ ?> <?php echo $data['artist'] ?>
                                            <a class="icon-eye" href="<?php print_link("music/view_artist/artist/$data[artist]");?>"></a>
                                            <?php } else { ?> <?php echo 'Uknown Artist' ?> <?php } ?>
                                        </span>
                                        <span class="d-block mb-2">
                                            <i class="icon-globe mr-3"></i> 
                                            <span class="mr-2">Host: </span>
                                            <?php echo SITE_NAME ?>
                                        </span>
                                        <span class="d-block mb-2">
                                            <i class="icon-clock mr-3"></i> 
                                            <span class="mr-2">Date: </span>
                                            <?php echo human_date($data['date']) ?>
                                        </span>
                                        <span class="d-block mt-3">
                                            <a class="btn btn-sm border "><i class="icon-pin mr-2"></i></a>
                                            <a class="btn btn-sm border "><i uk-icon="plus" class="mr-2"></i></a>
                                            <a class="btn btn-sm border "><i class="icon-heart mr-2"></i></a>
                                            <a class="btn btn-sm border "><i class="icon-cloud-download mr-2"></i></a>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div></div>
                </div>
            </div>
        </div>
    </div>
</section>
