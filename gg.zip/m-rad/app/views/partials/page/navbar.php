<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="container-fluid">
            <div class="row ">
                <div class=" col-md-4 col-lg-3 col-sm-4 d-sm-block d-none comp-grid">
                    <div  class="">
                        <div class="container">
                            <div class="row ">
                                <div class="animated bounce col-sm-12 mb-5 comp-grid">
                                    <div class="text-dangre"><div class="">
                                        <h4 class="display-5 text-danger">
                                            Settings
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 comp-grid">
                                <div ><h4 class="">
                                    <div class="mb-3">
                                        <i uk-icon="icon: nut; ratio:1.5;" class="mr-2"></i><a class="">General</a>
                                    </div>
                                    <div class="mb-3 text-light">
                                        <i uk-icon="icon: nut; ratio:1.5;" class="mr-2"></i><a class="">Personalize</a>
                                    </div>
                                    <div class="mb-3 text-light">
                                        <i uk-icon="icon: nut; ratio:1.5;" class="mr-2"></i><a class="">Account</a>
                                    </div>
                                </h4></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col setting-content bg-white h-100 scrollbar-0 comp-grid">
                <div  class="">
                    <div class="container">
                        <div class="row ">
                            <div class="col-sm-12 py-5 comp-grid">
                                <div class=""><div>
                                    <?php if(!empty($records)){?>
                                    <div class="">
                                        <div class="">
                                            <?php
                                            $counter = 0;
                                            foreach($records as $data){
                                            $rec_id = (!empty($data['']) ? urlencode($data['']) : null);
                                            $counter++;
                                            ?>
                                            <div clas="">
                                                <di class="row">
                                                    <div class="col-10">
                                                        <div class="bold"><?php echo $data['option'];?></div>
                                                        <div class="">
                                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit ipsum dolor sit amet.
                                                        </div>
                                                    </div>
                                                    <div class="col-2">
                                                    </div>
                                                </di>
                                            </div>
                                            <hr>
                                                <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
