<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="pb-5">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-12 p-0 mb-2 ">
                    <div class="col-12 banner"  uk-sticky="media: 574"  id=""><div class="justify-content-between align-items-end">
                        <div class="">
                            <a class="btn p-0" onclick="goback()"><i class="icon-arrow-left"></i></a>
                        </div>
                        <div class="col-12 p-0 display-5 text-theme pt-3 text-truncate">
                            Browse
                        </div>
                        <div class="col-12 p-0">
                            <a class="btn btn-sm border-left">
                                <i class="icon-shuffle mr-1"></i> Shuffle (24)
                            </a>
                            <a class="btn btn-sm">
                                <i class="icon-drop mr-1"></i> Sort by 
                                <span class="text-muted bold">A</span> - <span class="text-muted bold">Z</span>
                            </a>
                            <a class="dropdown">
                                <a class="btn btn-sm mrad-btn" data-toggle="dropdown">
                                    <i class="icon-arrow-down"></i>
                                </a>
                                <div class="dropdown-menu shadow border-0">
                                    <a class="dropdown-item">
                                        <i class="icon-grid mr-2"></i> Option One
                                    </a>
                                    <a class="dropdown-item">
                                        <i class="icon-grid mr-2"></i> Switch Grid
                                    </a>
                                </div>
                            </a>
                            <span class="d-none d-md-none d-sm-inline">
                                <form class="uk-search uk-search-default">
                                    <span uk-search-icon></span>
                                    <input class="uk-search-input" placeholder="Search" name="search" type="search" autocomplete="off"></input>
                                </form>
                            </span>
                        </div>
                    </div></div>
                </div>
                <div class="col-md-12 comp-grid">
                    <div ><?php 
                        if(!empty($records)){?>
                        <div class="" id="indexcategor">
                            <div class="row">
                                <?php 
                                $counter =  0;
                                foreach($records as $data){
                                $rec_id = (!empty($data['id']) ? urlencode($data['id']):null);
                                $counter ++;?>
                                <div class="col-12 mb-md-3 category<?php echo $rec_id?>" id="category<echo $counter?>">
                                    <div class="row p-1 justify-content-between mb-2">
                                        <h4 class="text-auto col-auto p-0 my-title"><?php echo $data['title'];?></h4>
                                        <div class="col-auto p-0 text-right">
                                            <a class="btn btn-sm text-auto  p-0" href="<?php print_link("page/track?search=$data[title]");?>"> More <i class="icon-arrow-right small"></i></a>
                                        </div>
                                    </div>
                                    <div class="">
                                        <?php $this->render_page("subpage/track/role/$data[title]");?>
                                    </div>
                                </div>
                                <?php 
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                        }
                    ?></div>
                </div>
            </div>
        </div>
    </div>
</section>
