<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <div  class="">
        <div class="">
            <div class="row ">
                <div class="col theme ">
                    <div class="genaral"><?php if($data['brand'] == 'true'){$navbrand = 'Twozik' ; } else { $navbrand = SITE_NAME ; }?>
                        <style>
                            .bg-theme{
                            background:<?php echo $data['color']?>;
                            }
                            .text-theme {
                            color: <?php echo $data['color']?>;
                            }
                            .mrad-repo-toggle .active{
                            border:2px solid <?php echo $data['color']?>;
                            border-width:0 0 2px 0;
                            }
                            #navbrand:after {
                            content: "<?php echo $navbrand ?>";
                            }
                            .theme-1gt{
                            background:linear-gradient(to top left,#FF00<?php echo random_num(2,'369')?>,<?php if($data['accent'] == 'true'){ echo $data['color'];} else { ?> #3497<?php echo random_chars(2,'DBCEF'); } ?>);
                            color:white;
                            }
                        </style>
                    </div>
                    <div class="white"><style>
                        <?php if($data['theme'] == 'white'){ ?>
                        .banner{
                        background: white;
                        }
                        .stripe-hover{
                        background:rgba(0,0,0,0.1);
                        }
                        .mrad-hover:hover{
                        background:rgba(0,0,0,0.2);
                        }
                        .form-control, .form-control:focus {
                        background: rgba(255,255,255,0.4);
                        color: rgba(0,0,0,0.9);
                        }
                        .theme-bw{ /*black and white switch*/
                        background:white;
                        }
                        .text-auto, .custom-select, .text-auto:hover {
                        color: rgba(0,0,0,0.9) !important;
                        }
                        .mrad-search, .custom-select{
                        background:rgba(255,255,255,0.4);
                        }
                        .skinned{
                        background: rgba(0,0,0,0.07);
                        }
                        .mrad-spinner{
                        background: white;
                        }
                        .mp-view{
                        background: rgba(0,0,0,0.7);
                        color: rgba(255,255,255,0.7);
                        }
                        .f-icon{
                        color:black;
                        }
                        .f-icon:hover{
                        color:black;
                        }
                        .nav-item{
                        color: rgba(0,0,0,0.7543);
                        }
                        .nav-item:hover{
                        color: rgba(0,0,0,0.7543);
                        }
                        .mrad-res-cleck:active{
                        background: rgba(0,0,0,0.5);
                        }
                        .mrad-resp-cleck:hover{
                        background: rgba(0,0,0,0.2);
                        }
                        .mrad-navbrand{
                        color:black;
                        }
                        body, .bg.theme {
                        background: white;
                        }
                        .mrad-body, .mrad-sidenav{
                        background: rgba(0,0,0,0,0.3);
                        }
                        .m-control-icon {
                        color:white;
                        border-width:0px;
                        border-radius: 50px;
                        height:45px;
                        width:45px;
                        }
                        @media(min-width: 574px){
                        .mrad-mp{
                        background: white;
                        }
                        .mp-togller-holder{
                        bottom:0px; right:10px;border-radius:50px 50px 0 0
                        }
                        }
                        @media(max-width: 575px){
                        .mrad-mp{
                        background: rgba(255,255,255,0.54);
                        backdrop-filter: blur(20px);
                        }
                        .mp-togller-holder{
                        bottom:100px; right:0px;border-radius:50px 0 0 50px;
                        }
                        }
                        <?php } ?>
                    </style></div>
                    <div class="light"><style>
                        <?php if($data['theme'] == 'light'){ ?>
                        .banner{
                        background: #f0f0f8;
                        }
                        .stripe-hover{
                        background:rgba(0,0,0,0.1);
                        }
                        .mrad-hover:hover{
                        background:rgba(0,0,0,0.2);
                        }
                        .form-control, .form-control:focus {
                        background: rgba(255,255,255,0.4);
                        color: rgba(0,0,0,0.9);
                        }
                        .theme-bw{ /*black and white switch*/
                        background:white;
                        }
                        .text-auto, .custom-select, .text-auto:hover {
                        color: rgba(0,0,0,0.9) !important;
                        }
                        .mrad-search, .custom-select{
                        background:rgba(255,255,255,0.4);
                        }
                        .skinned{
                        background: rgba(0,0,0,0.07);
                        }
                        .mrad-spinner{
                        background: #f0f0f8;
                        }
                        .mp-view{
                        background: rgba(0,0,0,0.7);
                        color: rgba(255,255,255,0.7);
                        }
                        .f-icon{
                        color:black;
                        }
                        .f-icon:hover{
                        color:black;
                        }
                        .nav-item{
                        color: rgba(0,0,0,0.6543);
                        }
                        .nav-item:hover{
                        color: rgba(0,0,0,0.6543);
                        }
                        .mrad-res-cleck:active{
                        background: rgba(0,0,0,0.5);
                        }
                        .mrad-resp-cleck:hover{
                        background: rgba(0,0,0,0.2);
                        }
                        .mrad-navbrand{
                        color:black;
                        }
                        body, .bg.theme {
                        background: #f0f0f8;
                        }
                        .mrad-body, .mrad-sidenav{
                        background: rgba(0,0,0,0,0.3);
                        }
                        .m-control-icon {
                        color:white;
                        border-width:0px;
                        border-radius: 50px;
                        height:45px;
                        width:45px;
                        }
                        @media(min-width: 574px){
                        .mrad-mp{
                        background: #f0f0f8;
                        }
                        .mp-togller-holder{
                        bottom:0px; right:10px;border-radius:50px 50px 0 0
                        }
                        }
                        @media(max-width: 575px){
                        .mrad-mp{
                        background: rgba(255,255,255,0.54);
                        backdrop-filter: blur(20px);
                        }
                        .mp-togller-holder{
                        bottom:100px; right:0px;border-radius:50px 0 0 50px;
                        }
                        }
                        <?php } ?>
                    </style></div>
                    <div class="dark"><style>
                        <?php if($data['theme'] == 'dark') { ?>
                        .banner {
                        background: #4A4A4D;
                        }
                        .stripe-hover{
                        background:rgba(0,0,0,0.1);
                        }
                        .mrad-hover:hover{
                        background:rgba(0,0,0,0.2);
                        }
                        .form-control, .form-control:focus {
                        background: rgba(0,0,0,0.4);
                        color: rgba(255,255,255,0.9);
                        }
                        .custom-select, .custom-select:focus {
                        background: rgba(0,0,0,0.4);
                        }
                        .theme-bw { /*black and white switch*/
                        background: #101012;
                        }
                        .text-auto, .text-auto:hover {
                        color: rgba(255,255,255,0.9);
                        }
                        .mrad-search {
                        background: rgba(0,0,0,0.4);
                        border-width:0;
                        }
                        .skinned {
                        background: rgba(0,0,0,0.3);
                        }
                        .mrad-spinner {
                        background: #4A4A4D;
                        }
                        .mp-view{
                        background: rgba(0,0,0,0.9);
                        color: rgba(255,255,255,0.7);
                        }
                        .f-icon{
                        color:white;
                        }
                        .f-icon:hover{
                        color:white;
                        }
                        .nav-item{
                        color: rgba(255,255,255,0.543);
                        }
                        .nav-item:hover{
                        color: rgba(255,255,255,0.543);
                        }
                        .mrad-res-cleck:active{
                        background: rgba(255,255,255,0.5);
                        }
                        .mrad-resp-cleck:hover{
                        background: rgba(255,255,255,0.2);
                        }
                        .mrad-navbrand{
                        color: #ff0039;
                        }
                        body, .bg.theme {
                        background: #4A4A4D;
                        color:rgba(255,255,255,0.7);
                        }
                        .mrad-body, .mrad-sidenav{
                        background: rgba(0,0,0,0,0.3);
                        }
                        .m-control-icon {
                        color:white;
                        border-width:0px;
                        border-radius: 50px;
                        height:45px;
                        width:45px;
                        }
                        @media(min-width: 574px){
                        .mrad-mp{
                        background: #A4A4AD;
                        }
                        .mp-togller-holder{
                        bottom:0px; right:10px;border-radius:50px 50px 0 0
                        }
                        }
                        @media(max-width: 575px){
                        .mrad-mp{
                        background: rgba(0,0,0,0.54);
                        backdrop-filter: blur(20px);
                        }
                        .mp-togller-holder{
                        bottom:100px; right:0px;border-radius:50px 0 0 50px;
                        }
                        }
                        <?php } ?>
                    </style></div>
                    <div class="black"><style>
                        <?php if($data['theme'] == 'black') { ?>
                        .banner{
                        background: #101012;
                        }
                        .stripe-hover{
                        background:rgba(255,255,255,0.1);
                        }
                        .mrad-hover:hover{
                        background:rgba(255,255,255,0.2);
                        }
                        .form-control, .form-control:focus {
                        background: rgba(255,255,255,0.2);
                        color: rgba(255,255,255,0.9);
                        }
                        .custom-select, .custom-select:focus {
                        background: rgba(255,255,255,0.2);
                        }
                        .theme-bw{ /*black and white switch*/
                        background: black;
                        }
                        .text-auto, .text-auto:hover {
                        color: rgba(255,255,255,0.9);
                        }
                        .mrad-search{
                        background: rgba(255,255,255,0.2);
                        border-width:0;
                        }
                        .skinned{
                        background: rgba(0,0,0,1);
                        }
                        .mrad-spinner{
                        background: #101012;
                        }
                        .mp-view{
                        background: rgba(0,0,0,0.9);
                        color: rgba(255,255,255,0.7);
                        }
                        .f-icon{
                        color:white;
                        }
                        .f-icon:hover{
                        color:white;
                        }
                        .nav-item{
                        color: rgba(255,255,255,0.543);
                        }
                        .nav-item:hover{
                        color: rgba(255,255,255,0.543);
                        }
                        .mrad-res-cleck:active{
                        background: rgba(255,255,255,0.5);
                        }
                        .mrad-resp-cleck:hover{
                        background: rgba(255,255,255,0.2);
                        }
                        .mrad-navbrand{
                        color: #ff0039;
                        }
                        body, .bg.theme {
                        background: #101012;
                        color:rgba(255,255,255,0.7);
                        }
                        .mrad-body, .mrad-sidenav{
                        background: rgba(0,0,0,0,0.3);
                        }
                        .m-control-icon {
                        color:white;
                        border-width:0px;
                        border-radius: 50px;
                        height:45px;
                        width:45px;
                        }
                        @media(min-width: 574px){
                        .mrad-mp{
                        background: #101012;
                        }
                        .mp-togller-holder{
                        bottom:0px; right:10px;border-radius:50px 50px 0 0
                        }
                        }
                        @media(max-width: 575px){
                        .mrad-mp{
                        background: rgba(0,0,0,0.74);
                        backdrop-filter: blur(20px);
                        }
                        .mp-togller-holder{
                        bottom:100px; right:0px;border-radius:50px 0 0 50px;
                        }
                        }
                        <?php } ?>
                    </style></div>
                </div>
                <div class="col switches ">
                    <div ></div>
                </div>
            </div>
        </div>
    </div>
</section>
