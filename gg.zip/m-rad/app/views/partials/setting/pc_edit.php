<?php
$comp_model = new SharedController;
$page_element_id = "edit-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="edit"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <div  class="accordion-group">
        <div class="container-fluid">
            <div class="row ">
                <div class=" col-md-4 col-lg-3 col-sm-4 col-sm-1 col-2 h-full ">
                    <div  class="">
                        <div class="container-fluid">
                            <div class="row ">
                                <div class="col-sm-12 comp-grid">
                                    <div ><div class="mt-2 pb-4">
                                        <a class="btn p-0 mb-3" onclick="goback()"><i class="icon-arrow-left"></i></a>
                                        <h4 class="display-5 text-theme">
                                            <span class="d-sm-none d-block"><i class="icon-settings"></i></span>
                                            <span class="d-sm-block d-none">Settings</span>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 comp-grid">
                                <div ><div class="text-auto nav">
                                    <div class="col-12 p-0 mb-3 shadow-0" data-toggle="tab" href="#setthemes" role="tab">
                                        <i class="icon-picture d-sm-none"></i>
                                        <h4 class="d-sm-inline text-auto d-none">Theme</h4>
                                    </div>
                                    <div class="col-12 p-0 mb-3 shadow-0" data-toggle="tab" href="#settpersonalize" role="tab">
                                        <i class="icon-magic-wand d-sm-none"></i>
                                        <h4 class="d-sm-inline text-auto d-none">Personalize</h4>
                                    </div>
                                    <div class="col-12 p-0 mb-3 shadow-0" data-toggle="tab" href="#settmore" role="tab">
                                        <i class="icon-user d-sm-none"></i>
                                        <h4 class="d-sm-inline text-auto d-none">Account</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col p-0 skinned set-parent scrollbar-0 pb-md-0  pb-5 ">
            <div class="h-full"><form novalidate  id="settparent" role="form" enctype="multipart/form-data"  class="form tab-content mb-4 page-form form-horizontal needs-validation" action="<?php print_link("setting/pc_edit/$page_id/?csrf_token=$csrf_token"); ?>" method="post" role="tablist" >
                <!--save button-->
                <div class="mb-5 mt-2">
                    <div class="form-ajax-status"></div>
                    <div class="form-group text-right">
                        <button class="btn bg-theme text-white" type="submit"> Save Chages </button>
                    </div> 
                </div>
                <!--theme-->
                <div class="col-12 tab-pane show active" id="setthemes" >
                    <div class="mb-3 col-12 text-right">
                        <h2 class="text-auto">Themes</h2>
                    </div>
                    <!--theme-->
                    <div class="row align-items-end">
                        <div class="col-sm-8 col-12 ">
                            <div class="bold mb-2">Theme</div>
                            <div class="text-muetd small">
                                By deault your theme is set to light, you can choose from the options provided
                            </div>
                        </div>
                        <div class="col pl-sm-3">
                            <select required=""  id="ctrl-theme" name="theme"  placeholder="Select a value ..."    class="custom-select" >
                                <option value="">Select a value ...</option>
                                <?php
                                $theme_options = Menu :: $theme;
                                $field_value = $data['theme'];
                                if(!empty($theme_options)){
                                foreach($theme_options as $option){
                                $value = $option['value'];
                                $label = $option['label'];
                                $selected = ( $value == $field_value ? 'selected' : null );
                                ?>
                                <option <?php echo $selected ?> value="<?php echo $value ?>">
                                    <?php echo $label ?>
                                </option>                                   
                                <?php
                                }
                                }
                                ?>    
                            </select>
                        </div>
                    </div>
                    <hr>
                        <!--color-->
                        <div class="row align-items-end">
                            <div class="col-sm-8 col-12 ">
                                <div class="bold mb-2">Text Color</div>
                                <div class="text-muetd small">
                                    Set to redy-pink on deafualt, you can choose from the options provided
                                </div>
                            </div>
                            <div class="col pl-sm-3">
                                <select required=""  id="ctrl-color" name="color"  placeholder="Select a value ..."    class="custom-select" >
                                    <option value="">Select a value ...</option>
                                    <?php
                                    $color_options = Menu :: $color;
                                    $field_value = $data['color'];
                                    if(!empty($color_options)){
                                    foreach($color_options as $option){
                                    $value = $option['value'];
                                    $label = $option['label'];
                                    $selected = ( $value == $field_value ? 'selected' : null );
                                    ?>
                                    <option <?php echo $selected ?> value="<?php echo $value ?>">
                                        <?php echo $label ?>
                                    </option>                                   
                                    <?php
                                    }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <hr>
                            <!--accent color-->
                            <div class="row align-items-end">
                                <div class="col-sm-8 col-12 ">
                                    <div class="bold mb-2">Album Cover</div>
                                    <div class="text-muetd small">
                                        Enable smart-skin to pick from theme as album cover
                                    </div>
                                </div>
                                <div class="col pl-sm-3 text-right">
                                    <input type="checkbox" id="ctrl-accent" value="<?php  echo $data['accent']; ?>" class="switch-checkbox" data-on="true" data-off="false"  data-name="accent" data-onlabel="True" data-offlabel="False" />
                                        <input type="hidden" name="accent"  value="<?php  echo $data['accent']; ?>" />
                                        </div>
                                    </div>
                                </div>
                                <!--personalize-->
                                <div class="col-12 tab-pane " id="settpersonalize" >
                                    <div class="mb-3 col-12 text-right">
                                        <h3 class="text-auto">Personalize</h3>
                                    </div>
                                    <!--brand-->
                                    <div class="row align-items-end">
                                        <div class="col-sm-8 col-12 ">
                                            <div class="bold mb-2">Name and Brand</div>
                                            <div class="text-muetd small">
                                                Replace brand name (<?php echo SITE_NAME ?>) to your name
                                            </div>
                                        </div>
                                        <div class="col pl-sm-3 text-right">
                                            <input type="checkbox" id="ctrl-brand" value="<?php  echo $data['brand']; ?>" class="switch-checkbox" data-on="true" data-off="false"  data-name="brand" data-onlabel="True" data-offlabel="False" />
                                                <input type="hidden" name="brand"  value="<?php  echo $data['brand']; ?>" />
                                                </div>
                                            </div>
                                            <hr>
                                                <!--sidenav-->
                                                <div class="row align-items-end">
                                                    <div class="col-sm-8 col-12 ">
                                                        <div class="bold mb-2">Collapse sidenav</div>
                                                        <div class="text-muetd small">
                                                            Make sidenav small by collapsing nav text 
                                                        </div>
                                                    </div>
                                                    <div class="col pl-sm-3 text-right">
                                                        <input type="checkbox" id="ctrl-auto_collapse" value="<?php  echo $data['auto_collapse']; ?>" class="switch-checkbox" data-on="true" data-off="false"  data-name="brand" data-onlabel="True" data-offlabel="False" />
                                                            <input type="hidden" name="auto_collapse"  value="<?php  echo $data['auto_collapse']; ?>" />
                                                            </div>
                                                        </div>
                                                        <hr>
                                                            <!--loop-->
                                                            <div class="row align-items-end">
                                                                <div class="col-sm-8 col-12 ">
                                                                    <div class="bold mb-2">Loop track</div>
                                                                    <div class="text-muetd small">
                                                                        Repeat track on play till you pause/stop it
                                                                    </div>
                                                                </div>
                                                                <div class="col pl-sm-3 text-right">
                                                                    <input type="checkbox" id="ctrl-autoplay" value="<?php  echo $data['autoplay']; ?>" class="switch-checkbox" data-on="true" data-off="false"  data-name="brand" data-onlabel="True" data-offlabel="False" />
                                                                        <input type="hidden" name="autoplay"  value="<?php  echo $data['autoplay']; ?>" />
                                                                        </div>
                                                                    </div>
                                                                    <hr>
                                                                        <!--auto save-->
                                                                        <div class="row align-items-end">
                                                                            <div class="col-sm-8 col-12 ">
                                                                                <div class="bold mb-2">Auto save</div>
                                                                                <div class="text-muetd small">
                                                                                    <i><?php echo ucwords(SITE_NAME) ?> Team</i> is currently working on this feature
                                                                                </div>
                                                                            </div>
                                                                            <div class="col pl-sm-3 text-right">
                                                                                <input type="checkbox" id="ctrl-autosave" value="<?php  echo $data['autosave']; ?>" class="switch-checkbox" data-on="true" data-off="false"  data-name="brand" data-onlabel="True" data-offlabel="False" />
                                                                                    <input type="hidden" name="autosave"  value="<?php  echo $data['autosave']; ?>" />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!--more options-->
                                                                            <div class="col-12 tab-pane settmore" id="settmore" >
                                                                                <div class="mb-3 col-12 text-right">
                                                                                    <h3 class="text-auto">General</h3>
                                                                                </div>
                                                                                <!--newslater-->
                                                                                <div class="row align-items-end">
                                                                                    <div class="col-sm-8 col-12 ">
                                                                                        <div class="bold mb-2">News latter</div>
                                                                                        <div class="text-muetd small">
                                                                                            How often do you want to get news later from <?php echo SITE_NAME ?>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col pl-sm-3">
                                                                                        <input id="ctrl-newslater"  value="<?php  echo $data['newslater']; ?>" type="text" placeholder="Enter Newslater"  required="" name="newslater"  class="form-control " />
                                                                                        </div>
                                                                                    </div>
                                                                                    <hr>
                                                                                    </div>
                                                                                </form></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </section>
