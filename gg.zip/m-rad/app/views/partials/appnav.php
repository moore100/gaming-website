<!--load spinner-->
<div class="mrad-spinner">
	<div class="spinner-border text-danger" style="height: 10rem,width: 10rem; border-width:2px;" role="status"></div>
</div>

<!-- mp now playing overlay panel  -->
<div class="mp-view scrollbar-0 d-none" id="mp-view">
	<!-- <div class="col-12"> -->
	    <div class="d-flex justify-content-between">
    	    <a class="btn text-white" onclick="mradToggle1('.mp-view','d-none')"><i class="icon-arrow-left"></i></a>
        </div>
        <div class="uk-overlay-bottom uk-overlay mt-5 p-md-5">
    	    <div class="row">
    		     <div class="col-9 animated bounce p-4 mb-4 col-sm-6 col-md-5 col-lg-3 col-xl-2">
    		     	<img class="rounded shadow-lg fill mrad-mp-img" src=""/>
    		     </div>
    		     <div class="col-12 p-0 mb-2">
    		     	<h3 class="audio-title display-5 text-light mb-2"></h3>
    		     	<hr>
    		     	<div class="mrad-title">Uknown Artist / Uknown Albume</div>
    		     </div>
    		     <div class="row align-items-center">
    		        <div class="col p-0 text-left btn btn-sm comp-grid">
                    <span class="btn text-light icon-heart"></span>
                    <span class="btn text-light icon-control-start"></span>
                    <span>
                        <button class="btn shadow-0 text-light p-2 d-inline m-control-icon theme-1gt" id="audioControllg" onclick="playpause('audioControllg')">
                	    <i class="icon-control-pause p-0"  ></i>
                        </button>	
                    </span>
                    <span class="btn text-light icon-control-end"></span>
                    <span class="btn text-light icon-loop"></span>
                   </div>
                </div>
    	    </div>
        </div>
    <!-- </div> -->
</div>


<!-- side menu for mobile  -->
<div class="mrad-mobile-menu">
	<div class="uk-modal-full uk-modal " uk-modal id="mrad-mobile-menu">
		<div class="col-12 uk-modal-dialog theme bg d-flex align-items-end pb-5" uk-height-viewport>

			<button class="uk-modal-close-full bg theme text-auto" uk-close></button>
			<div class="col-12 text-right">
			    <div class=" p-3">
			    	<img class="rounded-circle shadow" height="70px" width="70px" src="http://localhost/m-rad/assets/images/user.jpg">
			    </div>
			    <h3 class="bold p-2 text-auto">
			    	Twozikofficial
			    </h3>
			    <div class="bg-theme my-2 col-12" style="height:1px"></div>
			    <div class="" style="font-size:18px;">
			    	<a class="nav-item" href="<?php print_link('page/Artist');?>">
                        <span class="">Artist</span><i class="icon-people ml-3 alert-danger rounded-circle p-2"></i> 
                    </a>
			    	<a class="nav-item" href="<?php print_link('page/Album');?>">
                        <span class="">Album</span><i class="icon-microphone ml-3 alert-info rounded-circle p-2"></i> 
                    </a>
                    <div class="bg-theme my-2 col-12" style="height:1px"></div>
                    <a class="nav-item" href="<?php print_link('page/repository');?>">
                        <span class="">Repository</span><i class="icon-folder ml-3 alert-warning rounded-circle p-2"></i> 
                    </a>
                    <a class="nav-item" href="<?php print_link('#');?>">
                        <span class="">History</span><i class="icon-music-tone ml-3 alert-info rounded-circle p-2"></i> 
                    </a>
                    <?php $set_id = '1'?>
                    <a class="nav-item" href="<?php print_link("setting/view/$set_id")?>">
                        <span class="">Setting</span><i class="icon-settings ml-3 alert-success rounded-circle p-2"></i> 
                    </a>
                    <a class="nav-item" href="<?php print_link("setting/view/$set_id")?>">
                        <span class="">About</span><i class="icon-info ml-3 alert-primary rounded-circle p-2"></i> 
                    </a>
			</div>

		</div>
	</div>
</div>

<!-- mobile search panel -->
<div class="mrad-mobile-sidenav" >
	<div class="uk-modal-full uk-modal " uk-modal id="mrad-mobile-search">
		<div class="col-12 uk-modal-dialog theme bg d-flex align-items-center" uk-height-viewport>
			<button class="uk-modal-close-full bg theme text-auto" uk-close></button>
			<form class="uk-search uk-search-large" action="<?php print_link('page/search'); ?>" method="get">
				<i uk-search-icon></i>
				<input class="uk-search-input" type="search" name="search" placeholder="Search..." autocomplete="off" autofocus>
			</form>
		</div>
	</div>
</div>



<div class="section" id="ctrlHolder">
	<!-- media panel -->
    <div class="col-12 p-0 mp-theme section mrad-mp">
    <div class="row align-items-center mp-pc-holder mrad-toggle hide">
		<!-- image and text grouped-->
		<div class="col col-sm-auto col-md-4 mrad-resp-cleck comp-grid" onclick="mradToggle1('.mp-view','d-none')">
		<div class="row py-3 row  p-2">
			<div class="col-auto"><img class="rounded-circle ml-2 ml-sm-0 mrad-mp-img" height="30" width="30" id="img"></div>
			<div class="col">
				<div class="audio-title text-truncate btn btn-sm text-auto"></div>
			</div>
		</div>
	    </div>
		<!-- controls -->
		<div class="col-auto p-0 d-none d-sm-block comp-grid">
			<div class="btn btn-sm text-auto">
                <span class=" icon-heart"></span>
                <span class=" icon-control-start"></span>
                <span>
                    <button class="btn shadow-0 p-2 text-light d-inline m-control-icon theme-1gt" id="audioControlmd" onclick="playpause('audioControlmd')">
                	    <i class="icon-control-pause p-0"  ></i>
                    </button>	
                </span>
                
                <span class=" icon-control-end"></span>
                <span class=" icon-loop"></span>
            </div>
		</div>
		<!-- controls sm -->
		<div class="col-3 btn btn-sm text-auto p-0 d-sm-none d-block comp-grid">
			<span class="btn btn-sm p-0" id="audioControlsm" onclick="playpause('audioControlsm')">
                <i class="icon-control-pause"  ></i>
            </span>

			<span class="btn btn-sm pr-2">
				<i class="icon-heart"></i>
			</span>
			
		</div>
		<!-- seek -->
		<div class="col d-sm-block d-none comp-grid">
			<div class="col-9 bg-danger pt-1 rounded"></div>
		</div>
	</div>
    </div>

    <!-- panel toggle -->
    <div class="position-fixed theme-1gt p-1 px-2 mp-togller-holder mp-pc-holder hide" onclick="mradToggle('.mp-togller', 'icon-arrow-up icon-arrow-down', '.mrad-toggle')">
	    <i class="icon-arrow-down small mp-togller"></i>
    </div>

   <!-- small screen navbar footer -->
    <div class="col-12 d-block d-sm-none section bg bg theme">
	<div class="d-flex justify-content-between align-items-center" style="height:50px;">
		<div id="gohome">
		    <a id="Home" href="<?php print_link('Home')?>" class="no-d f-icon icon-home" style="font-size:20px;"></a>
		</div>
		<div id="gotone">
		    <a id="Tone" href="<?php print_link('category')?>" class="no-d f-icon icon-music-tone-alt" style="font-size:20px;"></a>
		</div>
		<div id="gosearch" class="uk-nav-light">
		    <a id="Search" href="#mrad-mobile-search" uk-toggle class="no-d f-icon icon-magnifier"></a>
		</div>
		<div id="goheart">
		    <a id="Heart" href="<?php print_link('page/repository')?>" class="no-d f-icon icon-folder"></a>
		</div>
        <div id="gomenu">
		    <a id="Menu" href="#mrad-mobile-menu" uk-toggle class="no-d f-icon icon-menu"></a>
		</div>
    </div>
    </div>
</div>