-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2020 at 07:14 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mrad_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `heart`
--

CREATE TABLE `heart` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `music`
--

CREATE TABLE `music` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `artist` varchar(255) NOT NULL,
  `album` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `audio` varchar(255) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `ctrl` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Stand-in structure for view `page`
-- (See below for the actual view)
--
CREATE TABLE `page` (
`id` int(11)
,`title` varchar(255)
,`artist` varchar(255)
,`album` varchar(255)
,`year` varchar(255)
,`audio` varchar(255)
,`cover` varchar(255)
,`date` varchar(255)
,`status` varchar(255)
,`role` varchar(255)
,`ctrl` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `playlist`
--

CREATE TABLE `playlist` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `theme` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `accent` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `auto_collapse` varchar(255) NOT NULL,
  `autoplay` varchar(255) NOT NULL,
  `autosave` varchar(255) NOT NULL,
  `newslater` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `user`, `theme`, `color`, `accent`, `brand`, `auto_collapse`, `autoplay`, `autosave`, `newslater`) VALUES
(1, 'public', 'white', '#FF0039', 'false', 'false', 'false', 'true', 'false', 'Weekly');

-- --------------------------------------------------------

--
-- Stand-in structure for view `subpage`
-- (See below for the actual view)
--
CREATE TABLE `subpage` (
`id` int(11)
,`title` varchar(255)
,`artist` varchar(255)
,`album` varchar(255)
,`year` varchar(255)
,`audio` varchar(255)
,`cover` varchar(255)
,`date` varchar(255)
,`status` varchar(255)
,`role` varchar(255)
,`ctrl` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `tools`
-- (See below for the actual view)
--
CREATE TABLE `tools` (
`id` int(11)
,`user` varchar(255)
,`theme` varchar(255)
,`color` varchar(255)
,`accent` varchar(255)
,`brand` varchar(255)
,`auto_collapse` varchar(255)
,`autoplay` varchar(255)
,`autosave` varchar(255)
,`newslater` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pswd` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure for view `page`
--
DROP TABLE IF EXISTS `page`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `page`  AS  select `m`.`id` AS `id`,`m`.`title` AS `title`,`m`.`artist` AS `artist`,`m`.`album` AS `album`,`m`.`year` AS `year`,`m`.`audio` AS `audio`,`m`.`cover` AS `cover`,`m`.`date` AS `date`,`m`.`status` AS `status`,`m`.`role` AS `role`,`m`.`ctrl` AS `ctrl` from `music` `m` ;

-- --------------------------------------------------------

--
-- Structure for view `subpage`
--
DROP TABLE IF EXISTS `subpage`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subpage`  AS  select `m`.`id` AS `id`,`m`.`title` AS `title`,`m`.`artist` AS `artist`,`m`.`album` AS `album`,`m`.`year` AS `year`,`m`.`audio` AS `audio`,`m`.`cover` AS `cover`,`m`.`date` AS `date`,`m`.`status` AS `status`,`m`.`role` AS `role`,`m`.`ctrl` AS `ctrl` from `music` `m` ;

-- --------------------------------------------------------

--
-- Structure for view `tools`
--
DROP TABLE IF EXISTS `tools`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tools`  AS  select `s`.`id` AS `id`,`s`.`user` AS `user`,`s`.`theme` AS `theme`,`s`.`color` AS `color`,`s`.`accent` AS `accent`,`s`.`brand` AS `brand`,`s`.`auto_collapse` AS `auto_collapse`,`s`.`autoplay` AS `autoplay`,`s`.`autosave` AS `autosave`,`s`.`newslater` AS `newslater` from `setting` `s` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `heart`
--
ALTER TABLE `heart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `music`
--
ALTER TABLE `music`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `playlist`
--
ALTER TABLE `playlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `heart`
--
ALTER TABLE `heart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `music`
--
ALTER TABLE `music`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `playlist`
--
ALTER TABLE `playlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
