<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbartopleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => ''
		),
		
		array(
			'path' => 'category', 
			'label' => 'Category', 
			'icon' => ''
		),
		
		array(
			'path' => 'heart', 
			'label' => 'Heart', 
			'icon' => ''
		),
		
		array(
			'path' => 'music', 
			'label' => 'Music', 
			'icon' => ''
		),
		
		array(
			'path' => 'playlist', 
			'label' => 'Playlist', 
			'icon' => ''
		),
		
		array(
			'path' => 'users', 
			'label' => 'Users', 
			'icon' => ''
		),
		
		array(
			'path' => 'tools', 
			'label' => 'Tools', 
			'icon' => ''
		),
		
		array(
			'path' => 'page', 
			'label' => 'Page', 
			'icon' => ''
		),
		
		array(
			'path' => 'subpage', 
			'label' => 'Subpage', 
			'icon' => ''
		),
		
		array(
			'path' => 'setting', 
			'label' => 'Setting', 
			'icon' => ''
		),
		
		array(
			'path' => 'tools', 
			'label' => 'Tools', 
			'icon' => ''
		),
		
		array(
			'path' => 'alerts', 
			'label' => 'Alerts', 
			'icon' => ''
		),
		
		array(
			'path' => 'blogs', 
			'label' => 'Blogs', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'blogs/Index', 
			'label' => 'Blogs', 
			'icon' => ''
		),
		
		array(
			'path' => 'blogs/all', 
			'label' => 'All', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'clans', 
			'label' => 'Clans', 
			'icon' => ''
		),
		
		array(
			'path' => 'comments', 
			'label' => 'Comments', 
			'icon' => ''
		),
		
		array(
			'path' => 'montage', 
			'label' => 'Montage', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'montage/Index', 
			'label' => 'Montage', 
			'icon' => ''
		),
		
		array(
			'path' => 'montage/all', 
			'label' => 'All', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'video', 
			'label' => 'Video', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'video/Index', 
			'label' => 'Video', 
			'icon' => ''
		),
		
		array(
			'path' => 'video/homevids', 
			'label' => 'Homevids', 
			'icon' => ''
		),
		
		array(
			'path' => 'video/loungevids', 
			'label' => 'Loungevids', 
			'icon' => ''
		),
		
		array(
			'path' => 'video/all', 
			'label' => 'All', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'blogs/blist', 
			'label' => 'Blist', 
			'icon' => ''
		),
		
		array(
			'path' => 'youtubechannels/yt', 
			'label' => 'Yt', 
			'icon' => ''
		),
		
		array(
			'path' => 'content_creators', 
			'label' => 'Content Creators', 
			'icon' => ''
		),
		
		array(
			'path' => 'content_creators/cc', 
			'label' => 'Cc', 
			'icon' => ''
		),
		
		array(
			'path' => 'alerts/homlert', 
			'label' => 'Homlert', 
			'icon' => ''
		),
		
		array(
			'path' => 'banner', 
			'label' => 'Banner', 
			'icon' => ''
		),
		
		array(
			'path' => 'banner/homebanner', 
			'label' => 'Homebanner', 
			'icon' => ''
		),
		
		array(
			'path' => 'mainhome', 
			'label' => 'Mainhome', 
			'icon' => ''
		),
		
		array(
			'path' => 'content_creators/ccreators', 
			'label' => 'Ccreators', 
			'icon' => ''
		),
		
		array(
			'path' => 'content_creators/creators', 
			'label' => 'Creators', 
			'icon' => ''
		),
		
		array(
			'path' => 'clans/homeclans', 
			'label' => 'Homeclans', 
			'icon' => ''
		),
		
		array(
			'path' => 'blogs/search', 
			'label' => 'Search', 
			'icon' => ''
		),
		
		array(
			'path' => 'clans/clanshome', 
			'label' => 'Clanshome', 
			'icon' => ''
		),
		
		array(
			'path' => 'montage/hometage', 
			'label' => 'Hometage', 
			'icon' => ''
		)
	);
		
	
	
			public static $role = array(
		array(
			"value" => "Admin", 
			"label" => "Admin", 
		),
		array(
			"value" => "User", 
			"label" => "User", 
		),);
		
			public static $theme = array(
		array(
			"value" => "white", 
			"label" => "White", 
		),
		array(
			"value" => "light", 
			"label" => "Light", 
		),
		array(
			"value" => "dark", 
			"label" => "Dart", 
		),
		array(
			"value" => "black", 
			"label" => "Black", 
		),);
		
			public static $color = array(
		array(
			"value" => "#FF0039", 
			"label" => "Default", 
		),
		array(
			"value" => "#9954BB", 
			"label" => "M-Indigo", 
		),
		array(
			"value" => "#FF7518", 
			"label" => "M-Orange", 
		),
		array(
			"value" => "#2780E3", 
			"label" => "M-Blue", 
		),
		array(
			"value" => "#3FB618", 
			"label" => "M-green", 
		),
		array(
			"value" => "#20c997", 
			"label" => "M-teal", 
		),);
		
}