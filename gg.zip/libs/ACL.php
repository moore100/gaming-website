<?php
/**
 * Page Access Control
 * @category  RBAC Helper
 */
defined('ROOT') or exit('No direct script access allowed');
class ACL
{
	

	/**
	 * Array of user roles and page access 
	 * Use "*" to grant all access right to particular user role
	 * @var array
	 */
	public static $role_pages = array(
			'admin' =>
						array(
							'category' => array('list','view','add','edit', 'editfield','delete','browse','sm_list','import_data'),
							'heart' => array('list','view','add','edit', 'editfield','delete','import_data'),
							'music' => array('list','view','add','edit', 'editfield','delete','pc_add','view_album','view_artist','sm_list','sm_view','import_data'),
							'playlist' => array('list','view','add','edit', 'editfield','delete','import_data'),
							'users' => array('list','view','userregister','accountedit','accountview','add','edit', 'editfield','delete','import_data'),
							'page' => array('list','view','track','artist','album','playlist','repository','search'),
							'subpage' => array('list','view','track','latest','random','artist','album','playlist','repo_tracks','repo_artists','repo_album','repo_playlist','repo_heart'),
							'setting' => array('list','view','add','edit', 'editfield','delete','pc_edit','import_data'),
							'tools' => array('list','view','navbar','sett_control'),
							'alerts' => array('list','view','add','edit', 'editfield','delete','homlert','import_data'),
							'blogs' => array('list','view','add','edit', 'editfield','delete','blist','search','all','import_data'),
							'clans' => array('list','view','add','edit', 'editfield','delete','homeclans','clanshome','import_data'),
							'comments' => array('list','view','add','edit', 'editfield','delete','import_data'),
							'montage' => array('list','view','add','edit', 'editfield','delete','hometage','all','import_data'),
							'video' => array('list','view','add','edit', 'editfield','delete','loungevids','all','import_data'),
							'content_creators' => array('list','view','add','edit', 'editfield','delete','cc','creators','import_data'),
							'banner' => array('list','view','add','edit', 'editfield','delete','homebanner','import_data'),
							'mainhome' => array('list','view','add','edit', 'editfield','delete','import_data')
						),
		
			'user' =>
						array(
							'montage' => array('list','view','add','edit', 'editfield','delete','all')
						)
		);

	/**
	 * Current user role name
	 * @var string
	 */
	public static $user_role = null;

	/**
	 * pages to Exclude From Access Validation Check
	 * @var array
	 */
	public static $exclude_page_check = array("", "index", "home", "account", "info", "masterdetail");

	/**
	 * Init page properties
	 */
	public function __construct()
	{	
		if(!empty(USER_ROLE)){
			self::$user_role = USER_ROLE;
		}
	}

	/**
	 * Check page path against user role permissions
	 * if user has access return AUTHORIZED
	 * if user has NO access return UNAUTHORIZED
	 * if user has NO role return NO_ROLE
	 * @return string
	 */
	public static function GetPageAccess($path)
	{
		$rp = self::$role_pages;
		if ($rp == "*") {
			return AUTHORIZED; // Grant access to any user
		} else {
			$path = strtolower(trim($path, '/'));

			$arr_path = explode("/", $path);
			$page = strtolower($arr_path[0]);

			//If user is accessing excluded access contrl pages
			if (in_array($page, self::$exclude_page_check)) {
				return AUTHORIZED;
			}

			$user_role = strtolower(USER_ROLE); // Get user defined role from session value
			if (array_key_exists($user_role, $rp)) {
				$action = (!empty($arr_path[1]) ? $arr_path[1] : "list");
				if ($action == "index") {
					$action = "list";
				}
				//Check if user have access to all pages or user have access to all page actions
				if ($rp[$user_role] == "*" || (!empty($rp[$user_role][$page]) && $rp[$user_role][$page] == "*")) {
					return AUTHORIZED;
				} else {
					if (!empty($rp[$user_role][$page]) && in_array($action, $rp[$user_role][$page])) {
						return AUTHORIZED;
					}
				}
				return FORBIDDEN;
			} else {
				//User does not have any role.
				return NOROLE;
			}
		}
	}

	/**
	 * Check if user role has access to a page
	 * @return Bool
	 */
	public static function is_allowed($path)
	{
		return (self::GetPageAccess($path) == AUTHORIZED);
	}

}
