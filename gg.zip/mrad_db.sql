-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2020 at 07:04 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mrad_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `id` int(11) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `headline` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `tag` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alerts`
--

INSERT INTO `alerts` (`id`, `banner`, `headline`, `description`, `date`, `tag`) VALUES
(1, 'dsfdsf', 'COMING SOON', 'sdfdsfsdfewdfsf', '2020-11-27 12:00:00', 'call of duty mobile'),
(2, 'http://localhost/m-rad/uploads/files/qn7v1_ab6ed4s9o.jpg', 'Podcast update ??????????', 'This is te coming soon description', '2020-11-17 12:00:00', 'call of duty mobile');

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `image`, `description`, `date`) VALUES
(1, 'http://localhost/m-rad/uploads/files/6vwo_ap4utcqz90.jpeg', 'description here', '2020-11-14 12:00:00'),
(2, 'uploads/files/qv0k_esf6phao24.jpg', 'Jaykenyaone builds', '2020-11-15 12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `headline` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `posted_by` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `banner`, `headline`, `category`, `tags`, `content`, `posted_by`, `date`) VALUES
(1, 'http://localhost/m-rad/uploads/files/t150wldj2henfpv.jpg', 'call of duty mobile', 'Podcast', 'how to', '<p>wqdqwdqwwqfqwfqwfqfqfqfqf</p>', 'Wahome mutahi', '2020-11-14 15:13:35'),
(2, 'http://localhost/m-rad/uploads/files/uw0rih23pe49gyn.jpg', 'new season is here', 'xcv', 'cxvx', '<p>grgr</p>', 'wahome', '2020-11-14 16:27:58');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `clans`
--

CREATE TABLE `clans` (
  `id` int(11) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `games` varchar(255) NOT NULL,
  `master` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `rank` varchar(255) NOT NULL,
  `wins` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clans`
--

INSERT INTO `clans` (`id`, `logo`, `name`, `status`, `games`, `master`, `contact`, `rank`, `wins`) VALUES
(1, 'uploads/files/ofj8cli3zeh9w6y.jpeg', 'NerdSquard', 'Recruiting', 'Call OfD', 'uty Mobile', '+254740161331', '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `bid` varchar(255) NOT NULL,
  `sender` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `content_creators`
--

CREATE TABLE `content_creators` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `api` varchar(255) NOT NULL,
  `twitch` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content_creators`
--

INSERT INTO `content_creators` (`id`, `name`, `logo`, `facebook`, `instagram`, `youtube`, `twitter`, `photo`, `description`, `date`, `api`, `twitch`) VALUES
(1, 'baping gamer', 'uploads/files/unrohjxat76450s.jpg', 'https://www.facebook.com/jymo.sta', 'https://www.instagram.com/stahjay/', 'https://www.youtube.com/user/EugeneAbuderby', 'https://www.instagram.com/stahjay/', 'uploads/files/qcy_b4kzfghil2x.jpg', 'justa normal guy', '2020-11-14 17:04:11', 'AIzaSyCbxkNthzdyF_iYk85qSs9KSrtnroNq8qw', ''),
(2, 'shoerack', 'uploads/files/ur3z7bm_wsi89dy.jpg', 'https://www.facebook.com/jymo.sta', 'https://www.facebook.com/jymo.sta', 'https://www.instagram.com/stahjay/', 'https://www.instagram.com/stahjay/', 'uploads/files/cx0rl6sp39f18vo.jpg', 'hjgjhg', '2020-11-14 17:22:02', '', ''),
(3, 'codler', 'uploads/files/6hnmp_4g8lc0d7x.jpg', 'https://www.facebook.com/jymo.sta', 'https://www.instagram.com/stahjay/', 'https://www.instagram.com/stahjay/', 'https://www.instagram.com/stahjay/', 'uploads/files/j_39r8psfi6h0m5.jpg', 'dfdsfsfsdfd', '2020-11-14 17:22:55', 'AIzaSyCbxkNthzdyF_iYk85qSs9KSrtnroNq8qw', ''),
(4, 'Eugene Abuderby', 'uploads/files/a1ngpzl4u9y5be2.jpg', 'https://www.facebook.com/jymo.sta', 'https://www.instagram.com/stahjay/', 'https://www.youtube.com/channel/UC9222G8lODzb-82E2_gQMsA', 'https://www.instagram.com/stahjay/', 'uploads/files/fwzuhv9spd1g76e.jpg', 'ad', '2020-11-14 17:23:46', 'AIzaSyCbxkNthzdyF_iYk85qSs9KSrtnroNq8qw', ' '),
(5, 'black', 'uploads/files/pud58bitcg126nh.jpg', 'https://www.facebook.com/jymo.sta', 'https://www.instagram.com/stahjay/', 'https://www.youtube.com/channel/UCogX2nzYLJ5OCUmCcWjPTJg', 'https://www.instagram.com/stahjay/', 'uploads/files/e6zkpmgbxcuiqaj.jpg', 'ad', '2020-11-14 17:25:20', 'AIzaSyCbxkNthzdyF_iYk85qSs9KSrtnroNq8qw', ''),
(6, 'XAdopted', 'uploads/files/lnzrmy4u69_op1s.jpeg', '', '', 'https://www.youtube.com/channel/UC_ZasAHVFmXIr5_-p1yuvgA', '', 'uploads/files/jsxa1fo4083yqmt.jpeg', 'description absent', '2020-11-15 16:33:35', 'AIzaSyCbxkNthzdyF_iYk85qSs9KSrtnroNq8qw', ' '),
(7, 'SilkStorm', 'uploads/files/xef21wltz3j6g_9.jpeg', '', '', 'https://www.youtube.com/channel/UC2FwiddYxUYTZmjJFSETe7A', '', 'uploads/files/ibq8s4x75j1ze0o.jpeg', 'Description Absent', '2020-11-15 17:48:41', 'AIzaSyCbxkNthzdyF_iYk85qSs9KSrtnroNq8qw', '  ');

-- --------------------------------------------------------

--
-- Table structure for table `heart`
--

CREATE TABLE `heart` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `mainhome`
--

CREATE TABLE `mainhome` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `montage`
--

CREATE TABLE `montage` (
  `id` int(11) NOT NULL,
  `ytlink` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `posted_by` varchar(255) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `headline` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `montage`
--

INSERT INTO `montage` (`id`, `ytlink`, `date`, `posted_by`, `banner`, `headline`) VALUES
(1, 'https://www.youtube.com/watch?v=9HTP7wFqSvc', '2020-11-16 11:27:27', 'some random guy', 'http://localhost/m-rad/uploads/files/w1rbkg_fa5nlthq.jpg', 'Fortnite  Montage');

-- --------------------------------------------------------

--
-- Table structure for table `music`
--

CREATE TABLE `music` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `artist` varchar(255) NOT NULL,
  `album` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `audio` varchar(255) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `ctrl` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `music`
--

INSERT INTO `music` (`id`, `title`, `artist`, `album`, `year`, `audio`, `cover`, `date`, `status`, `role`, `ctrl`) VALUES
(1, 'hmtym', 'tymt', 'tymtym', 'ytmtm', '', 'http://localhost/m-rad/uploads/files/ln0so36kw9af1br.jpg', '', '', 'gndfd', ''),
(2, 'graphs part 1b', 'sdg', 'test album', 'http://tun.in/tkplm1', '', 'http://localhost/m-rad/uploads/files/ws03mba4q1jfeip.jpg', '', '', 'sdgwew', '');

-- --------------------------------------------------------

--
-- Stand-in structure for view `page`
-- (See below for the actual view)
--
CREATE TABLE `page` (
`id` int(11)
,`title` varchar(255)
,`artist` varchar(255)
,`album` varchar(255)
,`year` varchar(255)
,`audio` varchar(255)
,`cover` varchar(255)
,`date` varchar(255)
,`status` varchar(255)
,`role` varchar(255)
,`ctrl` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `playlist`
--

CREATE TABLE `playlist` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `theme` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `accent` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `auto_collapse` varchar(255) NOT NULL,
  `autoplay` varchar(255) NOT NULL,
  `autosave` varchar(255) NOT NULL,
  `newslater` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `user`, `theme`, `color`, `accent`, `brand`, `auto_collapse`, `autoplay`, `autosave`, `newslater`) VALUES
(1, 'public', 'black', '#FF0039', 'true', 'true', 'true', 'true', 'false', 'Weekly');

-- --------------------------------------------------------

--
-- Stand-in structure for view `subpage`
-- (See below for the actual view)
--
CREATE TABLE `subpage` (
`id` int(11)
,`title` varchar(255)
,`artist` varchar(255)
,`album` varchar(255)
,`year` varchar(255)
,`audio` varchar(255)
,`cover` varchar(255)
,`date` varchar(255)
,`status` varchar(255)
,`role` varchar(255)
,`ctrl` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `tools`
-- (See below for the actual view)
--
CREATE TABLE `tools` (
`id` int(11)
,`user` varchar(255)
,`theme` varchar(255)
,`color` varchar(255)
,`accent` varchar(255)
,`brand` varchar(255)
,`auto_collapse` varchar(255)
,`autoplay` varchar(255)
,`autosave` varchar(255)
,`newslater` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pswd` varchar(255) DEFAULT NULL,
  `img` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `login_session_key` varchar(255) DEFAULT NULL,
  `email_status` varchar(255) DEFAULT NULL,
  `password_expire_date` datetime DEFAULT '2021-02-14 00:00:00',
  `password_reset_key` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `id` int(11) NOT NULL,
  `links` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `headline` varchar(255) DEFAULT NULL,
  `banner` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`id`, `links`, `date`, `headline`, `banner`) VALUES
(1, 'https://www.youtube.com/watch?v=1_OqCjZs5Jw', '2020-11-16 13:21:36', 'Call of duty mobile paid event ', 'http://localhost/m-rad/uploads/files/gqvji1mzyn6tpfe.jpg');

-- --------------------------------------------------------

--
-- Structure for view `page`
--
DROP TABLE IF EXISTS `page`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `page`  AS  select `m`.`id` AS `id`,`m`.`title` AS `title`,`m`.`artist` AS `artist`,`m`.`album` AS `album`,`m`.`year` AS `year`,`m`.`audio` AS `audio`,`m`.`cover` AS `cover`,`m`.`date` AS `date`,`m`.`status` AS `status`,`m`.`role` AS `role`,`m`.`ctrl` AS `ctrl` from `music` `m` ;

-- --------------------------------------------------------

--
-- Structure for view `subpage`
--
DROP TABLE IF EXISTS `subpage`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subpage`  AS  select `m`.`id` AS `id`,`m`.`title` AS `title`,`m`.`artist` AS `artist`,`m`.`album` AS `album`,`m`.`year` AS `year`,`m`.`audio` AS `audio`,`m`.`cover` AS `cover`,`m`.`date` AS `date`,`m`.`status` AS `status`,`m`.`role` AS `role`,`m`.`ctrl` AS `ctrl` from `music` `m` ;

-- --------------------------------------------------------

--
-- Structure for view `tools`
--
DROP TABLE IF EXISTS `tools`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tools`  AS  select `s`.`id` AS `id`,`s`.`user` AS `user`,`s`.`theme` AS `theme`,`s`.`color` AS `color`,`s`.`accent` AS `accent`,`s`.`brand` AS `brand`,`s`.`auto_collapse` AS `auto_collapse`,`s`.`autoplay` AS `autoplay`,`s`.`autosave` AS `autosave`,`s`.`newslater` AS `newslater` from `setting` `s` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clans`
--
ALTER TABLE `clans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content_creators`
--
ALTER TABLE `content_creators`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `heart`
--
ALTER TABLE `heart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mainhome`
--
ALTER TABLE `mainhome`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `montage`
--
ALTER TABLE `montage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `music`
--
ALTER TABLE `music`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `playlist`
--
ALTER TABLE `playlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alerts`
--
ALTER TABLE `alerts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clans`
--
ALTER TABLE `clans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `content_creators`
--
ALTER TABLE `content_creators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `heart`
--
ALTER TABLE `heart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mainhome`
--
ALTER TABLE `mainhome`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `montage`
--
ALTER TABLE `montage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `music`
--
ALTER TABLE `music`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `playlist`
--
ALTER TABLE `playlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
